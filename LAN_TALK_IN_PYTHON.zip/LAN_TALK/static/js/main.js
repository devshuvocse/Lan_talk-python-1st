// Main JavaScript for LAN_TALK application

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips and popovers if Bootstrap is loaded
    if (typeof bootstrap !== 'undefined') {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    // Dashboard functionality
    if (document.getElementById('refreshUsersBtn')) {
        document.getElementById('refreshUsersBtn').addEventListener('click', function() {
            // This will be replaced with WebSocket functionality later
            window.location.reload();
        });
    }

    // Chat button functionality
    const chatButtons = document.querySelectorAll('.start-chat');
    if (chatButtons) {
        chatButtons.forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-user-id');
                // This will be implemented when chat functionality is added
                alert('Chat functionality will be implemented in the next phase.');
                // Will redirect to: window.location.href = `/chat/${userId}/`;
            });
        });
    }

    // Voice call button functionality
    const voiceButtons = document.querySelectorAll('.start-voice');
    if (voiceButtons) {
        voiceButtons.forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-user-id');
                // This will be implemented when WebRTC is added
                alert('Voice call functionality will be implemented in the next phase.');
                // Will redirect to: window.location.href = `/call/voice/${userId}/`;
            });
        });
    }

    // Video call button functionality
    const videoButtons = document.querySelectorAll('.start-video');
    if (videoButtons) {
        videoButtons.forEach(button => {
            button.addEventListener('click', function() {
                const userId = this.getAttribute('data-user-id');
                // This will be implemented when WebRTC is added
                alert('Video call functionality will be implemented in the next phase.');
                // Will redirect to: window.location.href = `/call/video/${userId}/`;
            });
        });
    }

    // File sharing button functionality
    if (document.getElementById('shareFileBtn')) {
        document.getElementById('shareFileBtn').addEventListener('click', function() {
            // This will be implemented when file sharing is added
            alert('File sharing functionality will be implemented in the next phase.');
            // Will redirect to: window.location.href = '/files/share/';
        });
    }

    // Quick action buttons on dashboard
    if (document.getElementById('startChatBtn')) {
        document.getElementById('startChatBtn').addEventListener('click', function() {
            // This will be implemented when chat functionality is added
            alert('Please select a user to start chatting with.');
        });
    }

    if (document.getElementById('startVoiceBtn')) {
        document.getElementById('startVoiceBtn').addEventListener('click', function() {
            // This will be implemented when WebRTC is added
            alert('Please select a user to start a voice call with.');
        });
    }

    if (document.getElementById('startVideoBtn')) {
        document.getElementById('startVideoBtn').addEventListener('click', function() {
            // This will be implemented when WebRTC is added
            alert('Please select a user to start a video call with.');
        });
    }
});
