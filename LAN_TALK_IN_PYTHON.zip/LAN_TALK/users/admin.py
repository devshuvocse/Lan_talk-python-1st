from django.contrib import admin
from .models import Profile

class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'status', 'is_online', 'last_seen', 'ip_address')
    list_filter = ('is_online', 'last_seen')
    search_fields = ('user__username', 'status', 'ip_address')

admin.site.register(Profile, ProfileAdmin)
