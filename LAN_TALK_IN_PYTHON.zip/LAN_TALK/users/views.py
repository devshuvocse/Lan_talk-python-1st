from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegistrationForm, UserLoginForm, ProfileUpdateForm
from .models import Profile
from django.contrib.auth.models import User
import socket

def register(request):
    """
    View for user registration
    """
    if request.user.is_authenticated:
        return redirect('dashboard')
        
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Get client IP address for LAN identification
            x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
            if x_forwarded_for:
                ip = x_forwarded_for.split(',')[0]
            else:
                ip = request.META.get('REMOTE_ADDR')
            
            # Update user profile with IP
            profile = Profile.objects.get(user=user)
            profile.ip_address = ip
            profile.save()
            
            # Log the user in after registration
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            messages.success(request, f'Account created for {username}!')
            return redirect('dashboard')
    else:
        form = UserRegistrationForm()
    return render(request, 'users/register.html', {'form': form})

def login_view(request):
    """
    View for user login
    """
    if request.user.is_authenticated:
        return redirect('dashboard')
        
    if request.method == 'POST':
        form = UserLoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                # Update online status
                profile = Profile.objects.get(user=user)
                profile.is_online = True
                
                # Update IP address
                x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
                if x_forwarded_for:
                    ip = x_forwarded_for.split(',')[0]
                else:
                    ip = request.META.get('REMOTE_ADDR')
                profile.ip_address = ip
                profile.save()
                
                return redirect('dashboard')
    else:
        form = UserLoginForm()
    return render(request, 'users/login.html', {'form': form})

@login_required
def logout_view(request):
    """
    View for user logout
    """
    # Update online status
    profile = Profile.objects.get(user=request.user)
    profile.is_online = False
    profile.save()
    
    logout(request)
    return redirect('login')

@login_required
def profile(request):
    """
    View for user profile
    """
    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, instance=request.user.profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated!')
            return redirect('profile')
    else:
        form = ProfileUpdateForm(instance=request.user.profile)
    
    context = {
        'form': form
    }
    return render(request, 'users/profile.html', context)

@login_required
def dashboard(request):
    """
    View for user dashboard
    """
    # Get all online users except current user
    online_users = User.objects.filter(profile__is_online=True).exclude(id=request.user.id)
    
    context = {
        'online_users': online_users
    }
    return render(request, 'users/dashboard.html', context)
