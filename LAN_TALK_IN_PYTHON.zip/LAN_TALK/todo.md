# LAN_TALK Project Todo List

## Project Setup
- [x] Create project directory and virtual environment
- [x] Install Django and required packages
- [x] Initialize Django project structure
- [x] Create apps (users, chat, core)
- [x] Set up directory structure for templates, static files, and media

## User Authentication System
- [ ] Configure Django's built-in authentication system
- [ ] Create user model with required fields
- [ ] Implement registration view and template
- [ ] Implement login view and template
- [ ] Implement logout functionality
- [ ] Set up password hashing
- [ ] Create user profile model

## User Dashboard
- [ ] Design dashboard layout
- [ ] Implement online users display
- [ ] Add buttons for chat, voice call, and video call
- [ ] Create user profile section
- [ ] Set up status indicator functionality

## Real-time Messaging
- [ ] Configure Django Channels
- [ ] Set up WebSocket consumers
- [ ] Create chat room model
- [ ] Implement private messaging functionality
- [ ] Add message timestamps and sender info
- [ ] Design chat interface

## Voice and Video Call
- [ ] Integrate WebRTC
- [ ] Set up signaling with WebSockets
- [ ] Create call UI with JavaScript
- [ ] Implement peer-to-peer connection
- [ ] Add call controls (mute, end call, etc.)

## LAN Discovery Feature
- [ ] Create background script for user detection
- [ ] Implement WebSocket ping for online status
- [ ] Add online/offline indicators
- [ ] Set up automatic user discovery in subnet

## File Sharing System
- [ ] Create file model
- [ ] Implement file upload functionality
- [ ] Create download interface
- [ ] Add file expiration feature
- [ ] Set up file permissions

## Admin Panel
- [ ] Configure Django admin
- [ ] Create custom admin views
- [ ] Add user management features
- [ ] Implement basic analytics
- [ ] Set up ban/delete functionality

## Design and Layout
- [ ] Set up Bootstrap or Tailwind CSS
- [ ] Create responsive layout
- [ ] Design consistent UI components
- [ ] Implement mobile-friendly interface

## Database and Environment
- [ ] Configure SQLite for development
- [ ] Set up environment variables
- [ ] Create .env file for sensitive data
- [ ] Add database migration scripts

## Offline LAN Deployment
- [ ] Ensure all resources are available offline
- [ ] Replace CDN links with local files
- [ ] Test in offline environment
- [ ] Create deployment documentation

## Final Steps
- [ ] Test all functionality
- [ ] Fix bugs and issues
- [ ] Create comprehensive README.md
- [ ] Package and deliver codebase
