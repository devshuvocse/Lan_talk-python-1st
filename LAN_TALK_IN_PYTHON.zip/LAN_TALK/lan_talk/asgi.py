from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
import os
import chat.routing
import core.routing

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'lan_talk.settings')

application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": AuthMiddlewareStack(
        URLRouter(
            chat.routing.websocket_urlpatterns +
            core.routing.websocket_urlpatterns
        )
    ),
})
