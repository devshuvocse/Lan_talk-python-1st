from django.contrib import admin
from .models import ChatRoom, Message, SharedFile

class MessageInline(admin.TabularInline):
    model = Message
    extra = 0

class ChatRoomAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_at', 'get_participants')
    inlines = [MessageInline]
    
    def get_participants(self, obj):
        return ", ".join([user.username for user in obj.participants.all()])
    get_participants.short_description = 'Participants'

class MessageAdmin(admin.ModelAdmin):
    list_display = ('sender', 'room', 'content', 'timestamp')
    list_filter = ('room', 'sender', 'timestamp')
    search_fields = ('content',)

class SharedFileAdmin(admin.ModelAdmin):
    list_display = ('name', 'uploader', 'uploaded_at', 'expires_at', 'file_size')
    list_filter = ('uploader', 'uploaded_at', 'expires_at')
    search_fields = ('name',)

admin.site.register(ChatRoom, ChatRoomAdmin)
admin.site.register(Message, MessageAdmin)
admin.site.register(SharedFile, SharedFileAdmin)
