import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import ChatRoom, Message
from django.contrib.auth.models import User

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f'chat_{self.room_name}'
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        # Accept the connection
        await self.accept()
    
    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
    
    # Receive message from WebSocket
    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message = text_data_json['message']
        username = text_data_json['username']
        
        # Save message to database
        await self.save_message(username, message)
        
        # Send message to room group
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'message': message,
                'username': username
            }
        )
    
    # Receive message from room group
    async def chat_message(self, event):
        message = event['message']
        username = event['username']
        
        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'message': message,
            'username': username
        }))
    
    @database_sync_to_async
    def save_message(self, username, message):
        # Get the room and user
        room = ChatRoom.objects.get(name=self.room_name)
        user = User.objects.get(username=username)
        
        # Create and save the message
        Message.objects.create(
            room=room,
            sender=user,
            content=message
        )

class OnlineStatusConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.group_name = 'online_status'
        
        # Join online status group
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        
        # Accept the connection
        await self.accept()
        
        # Update user's online status
        user = self.scope['user']
        if user.is_authenticated:
            await self.update_user_status(user.id, True)
            
            # Notify all clients about the user's online status
            await self.channel_layer.group_send(
                self.group_name,
                {
                    'type': 'user_status',
                    'user_id': user.id,
                    'status': True
                }
            )
    
    async def disconnect(self, close_code):
        # Update user's online status
        user = self.scope['user']
        if user.is_authenticated:
            await self.update_user_status(user.id, False)
            
            # Notify all clients about the user's offline status
            await self.channel_layer.group_send(
                self.group_name,
                {
                    'type': 'user_status',
                    'user_id': user.id,
                    'status': False
                }
            )
        
        # Leave online status group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )
    
    # Receive status update from WebSocket
    async def receive(self, text_data):
        # This consumer doesn't expect to receive messages directly
        pass
    
    # Send status update to WebSocket
    async def user_status(self, event):
        user_id = event['user_id']
        status = event['status']
        
        # Send status update to WebSocket
        await self.send(text_data=json.dumps({
            'user_id': user_id,
            'status': status
        }))
    
    @database_sync_to_async
    def update_user_status(self, user_id, status):
        try:
            user = User.objects.get(id=user_id)
            user.profile.is_online = status
            user.profile.save()
        except User.DoesNotExist:
            pass
