from django.db import models
from django.contrib.auth.models import User
import os
import uuid

class ChatRoom(models.Model):
    """
    Model for chat rooms between users
    """
    name = models.CharField(max_length=100, unique=True)
    participants = models.ManyToManyField(User, related_name='chat_rooms')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name

class Message(models.Model):
    """
    Model for chat messages
    """
    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['timestamp']
    
    def __str__(self):
        return f"{self.sender.username}: {self.content[:20]}"

def file_upload_path(instance, filename):
    """
    Generate a unique path for uploaded files
    """
    ext = filename.split('.')[-1]
    filename = f"{uuid.uuid4()}.{ext}"
    return os.path.join('uploads', filename)

class SharedFile(models.Model):
    """
    Model for shared files between users
    """
    name = models.CharField(max_length=255)
    file = models.FileField(upload_to=file_upload_path)
    uploader = models.ForeignKey(User, on_delete=models.CASCADE, related_name='uploaded_files')
    shared_with = models.ManyToManyField(User, related_name='received_files')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    
    def __str__(self):
        return self.name
    
    @property
    def file_size(self):
        """Return file size in MB"""
        if self.file and hasattr(self.file, 'size'):
            return self.file.size / (1024 * 1024)
        return 0
