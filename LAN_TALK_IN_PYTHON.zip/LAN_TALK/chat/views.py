from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Q
from .models import ChatRoom, Message
import json
import uuid

@login_required
def chat_home(request):
    """
    View for chat home page showing all user's chat rooms
    """
    # Get all chat rooms where the current user is a participant
    chat_rooms = ChatRoom.objects.filter(participants=request.user)
    
    context = {
        'chat_rooms': chat_rooms
    }
    return render(request, 'chat/chat_home.html', context)

@login_required
def chat_room(request, room_name):
    """
    View for individual chat room
    """
    # Get the chat room or return 404
    room = get_object_or_404(ChatRoom, name=room_name)
    
    # Check if user is a participant in this room
    if request.user not in room.participants.all():
        return redirect('chat_home')
    
    # Get all messages in this room
    messages = Message.objects.filter(room=room)
    
    # Get other participants (for display purposes)
    other_participants = room.participants.exclude(id=request.user.id)
    
    context = {
        'room': room,
        'room_name_json': json.dumps(room_name),
        'username': request.user.username,
        'messages': messages,
        'other_participants': other_participants
    }
    return render(request, 'chat/chat_room.html', context)

@login_required
def create_chat(request, user_id):
    """
    View to create or get a chat room with another user
    """
    # Get the other user or return 404
    other_user = get_object_or_404(User, id=user_id)
    
    # Check if a chat room already exists between these users
    rooms = ChatRoom.objects.filter(participants=request.user).filter(participants=other_user)
    
    if rooms.exists():
        # If room exists, redirect to it
        room = rooms.first()
    else:
        # Create a new room with a unique name
        room_name = f"chat_{uuid.uuid4().hex[:10]}"
        room = ChatRoom.objects.create(name=room_name)
        room.participants.add(request.user, other_user)
        room.save()
    
    return redirect('chat_room', room_name=room.name)
