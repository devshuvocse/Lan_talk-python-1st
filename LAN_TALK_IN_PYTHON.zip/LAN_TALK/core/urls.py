from django.urls import path
from . import views
from . import file_views
from . import admin_views

urlpatterns = [
    path('call/', views.call_home, name='call_home'),
    path('call/voice/<int:user_id>/', views.voice_call, name='voice_call'),
    path('call/video/<int:user_id>/', views.video_call, name='video_call'),
    path('files/', file_views.file_home, name='file_home'),
    path('files/upload/', file_views.upload_file, name='upload_file'),
    path('files/download/<int:file_id>/', file_views.download_file, name='download_file'),
    path('files/delete/<int:file_id>/', file_views.delete_file, name='delete_file'),
    path('files/update-expiration/<int:file_id>/', file_views.update_expiration, name='update_expiration'),
    
    # Admin URLs
    path('admin/dashboard/', admin_views.admin_dashboard, name='admin_dashboard'),
    path('admin/users/', admin_views.admin_users, name='admin_users'),
    path('admin/ban-user/<int:user_id>/', admin_views.admin_ban_user, name='admin_ban_user'),
    path('admin/unban-user/<int:user_id>/', admin_views.admin_unban_user, name='admin_unban_user'),
    path('admin/delete-user/<int:user_id>/', admin_views.admin_delete_user, name='admin_delete_user'),
    path('admin/make-admin/<int:user_id>/', admin_views.admin_make_admin, name='admin_make_admin'),
    path('admin/remove-admin/<int:user_id>/', admin_views.admin_remove_admin, name='admin_remove_admin'),
    path('admin/files/', admin_views.admin_files, name='admin_files'),
    path('admin/delete-file/<int:file_id>/', admin_views.admin_delete_file, name='admin_delete_file'),
    path('admin/chats/', admin_views.admin_chats, name='admin_chats'),
    path('admin/delete-chat/<int:chat_id>/', admin_views.admin_delete_chat, name='admin_delete_chat'),
]
