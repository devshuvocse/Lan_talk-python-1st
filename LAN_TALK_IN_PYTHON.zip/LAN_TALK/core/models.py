from django.db import models

# This app will contain core functionality shared across the project
class CoreSettings(models.Model):
    """
    Model for storing application-wide settings
    """
    key = models.CharField(max_length=100, unique=True)
    value = models.TextField()
    description = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return self.key
