import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth.models import User

class CallSignalingConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user_id = self.scope['url_route']['kwargs']['user_id']
        self.call_group_name = f'call_{self.user_id}'
        
        # Join call group
        await self.channel_layer.group_add(
            self.call_group_name,
            self.channel_name
        )
        
        # Accept the connection
        await self.accept()
    
    async def disconnect(self, close_code):
        # Leave call group
        await self.channel_layer.group_discard(
            self.call_group_name,
            self.channel_name
        )
    
    # Receive message from WebSocket
    async def receive(self, text_data):
        data = json.loads(text_data)
        message_type = data['type']
        
        # Handle different types of WebRTC signaling messages
        if message_type == 'offer':
            # Forward offer to the target user
            target_user_id = data['target']
            offer = data['offer']
            caller_id = data['caller']
            
            await self.channel_layer.group_send(
                f'call_{target_user_id}',
                {
                    'type': 'call_offer',
                    'offer': offer,
                    'caller': caller_id
                }
            )
        
        elif message_type == 'answer':
            # Forward answer to the caller
            target_user_id = data['target']
            answer = data['answer']
            
            await self.channel_layer.group_send(
                f'call_{target_user_id}',
                {
                    'type': 'call_answer',
                    'answer': answer,
                    'answerer': self.user_id
                }
            )
        
        elif message_type == 'ice_candidate':
            # Forward ICE candidate to the target user
            target_user_id = data['target']
            candidate = data['candidate']
            
            await self.channel_layer.group_send(
                f'call_{target_user_id}',
                {
                    'type': 'ice_candidate',
                    'candidate': candidate,
                    'sender': self.user_id
                }
            )
        
        elif message_type == 'end_call':
            # Notify target user that call has ended
            target_user_id = data['target']
            
            await self.channel_layer.group_send(
                f'call_{target_user_id}',
                {
                    'type': 'end_call',
                    'sender': self.user_id
                }
            )
    
    # Handler for call offer message
    async def call_offer(self, event):
        offer = event['offer']
        caller = event['caller']
        
        # Send offer to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'offer',
            'offer': offer,
            'caller': caller
        }))
    
    # Handler for call answer message
    async def call_answer(self, event):
        answer = event['answer']
        answerer = event['answerer']
        
        # Send answer to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'answer',
            'answer': answer,
            'answerer': answerer
        }))
    
    # Handler for ICE candidate message
    async def ice_candidate(self, event):
        candidate = event['candidate']
        sender = event['sender']
        
        # Send ICE candidate to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'ice_candidate',
            'candidate': candidate,
            'sender': sender
        }))
    
    # Handler for end call message
    async def end_call(self, event):
        sender = event['sender']
        
        # Send end call notification to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'end_call',
            'sender': sender
        }))
