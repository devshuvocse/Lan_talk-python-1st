from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from django.utils import timezone
from django.contrib import messages
from .models import SharedFile
from django.contrib.auth.models import User
import os
import datetime

@login_required
def file_home(request):
    """
    View for file sharing home page
    """
    # Get files shared with the current user
    received_files = SharedFile.objects.filter(shared_with=request.user)
    
    # Get files uploaded by the current user
    uploaded_files = SharedFile.objects.filter(uploader=request.user)
    
    context = {
        'received_files': received_files,
        'uploaded_files': uploaded_files
    }
    return render(request, 'core/file_home.html', context)

@login_required
def upload_file(request):
    """
    View for uploading files
    """
    if request.method == 'POST':
        file = request.FILES.get('file')
        name = request.POST.get('name', file.name)
        expiration = request.POST.get('expiration', None)
        shared_with_ids = request.POST.getlist('shared_with')
        
        if file:
            # Create new file object
            shared_file = SharedFile.objects.create(
                name=name,
                file=file,
                uploader=request.user
            )
            
            # Set expiration time if provided
            if expiration and expiration != 'never':
                hours = int(expiration)
                shared_file.expires_at = timezone.now() + datetime.timedelta(hours=hours)
                shared_file.save()
            
            # Add users to share with
            if shared_with_ids:
                for user_id in shared_with_ids:
                    try:
                        user = User.objects.get(id=user_id)
                        shared_file.shared_with.add(user)
                    except User.DoesNotExist:
                        pass
            
            messages.success(request, f'File "{name}" uploaded successfully!')
            return redirect('file_home')
        else:
            messages.error(request, 'No file selected!')
    
    # Get all online users except current user
    online_users = User.objects.filter(profile__is_online=True).exclude(id=request.user.id)
    
    context = {
        'online_users': online_users
    }
    return render(request, 'core/upload_file.html', context)

@login_required
def download_file(request, file_id):
    """
    View for downloading files
    """
    shared_file = get_object_or_404(SharedFile, id=file_id)
    
    # Check if user has permission to download
    if request.user != shared_file.uploader and request.user not in shared_file.shared_with.all():
        messages.error(request, 'You do not have permission to download this file!')
        return redirect('file_home')
    
    # Check if file has expired
    if shared_file.expires_at and shared_file.expires_at < timezone.now():
        messages.error(request, 'This file has expired and is no longer available!')
        return redirect('file_home')
    
    # Get file path
    file_path = shared_file.file.path
    
    # Check if file exists
    if os.path.exists(file_path):
        with open(file_path, 'rb') as f:
            response = HttpResponse(f.read(), content_type='application/octet-stream')
            response['Content-Disposition'] = f'attachment; filename="{shared_file.name}"'
            return response
    else:
        messages.error(request, 'File not found!')
        return redirect('file_home')

@login_required
def delete_file(request, file_id):
    """
    View for deleting files
    """
    shared_file = get_object_or_404(SharedFile, id=file_id)
    
    # Check if user has permission to delete
    if request.user != shared_file.uploader:
        messages.error(request, 'You do not have permission to delete this file!')
        return redirect('file_home')
    
    # Delete file
    file_name = shared_file.name
    shared_file.delete()
    
    messages.success(request, f'File "{file_name}" deleted successfully!')
    return redirect('file_home')

@login_required
def update_expiration(request, file_id):
    """
    View for updating file expiration
    """
    if request.method == 'POST':
        shared_file = get_object_or_404(SharedFile, id=file_id)
        
        # Check if user has permission to update
        if request.user != shared_file.uploader:
            return JsonResponse({'status': 'error', 'message': 'Permission denied'})
        
        expiration = request.POST.get('expiration', None)
        
        if expiration == 'never':
            shared_file.expires_at = None
        elif expiration:
            hours = int(expiration)
            shared_file.expires_at = timezone.now() + datetime.timedelta(hours=hours)
        
        shared_file.save()
        
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})
