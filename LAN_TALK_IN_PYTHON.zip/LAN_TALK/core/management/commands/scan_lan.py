import os
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from users.models import Profile
import socket
import netifaces

class Command(BaseCommand):
    help = 'Scan local network for LAN_TALK users'

    def handle(self, *args, **options):
        self.stdout.write('Scanning local network for LAN_TALK users...')
        
        # Get local IP address and subnet
        local_ip = self.get_local_ip()
        subnet = self.get_subnet(local_ip)
        
        if not subnet:
            self.stdout.write(self.style.ERROR('Could not determine subnet.'))
            return
        
        self.stdout.write(f'Local IP: {local_ip}')
        self.stdout.write(f'Subnet: {subnet}')
        
        # Get all users with IP addresses
        users_with_ip = User.objects.filter(profile__ip_address__isnull=False)
        
        # Check which users are in the same subnet
        lan_users = []
        for user in users_with_ip:
            user_ip = user.profile.ip_address
            try:
                if self.is_in_subnet(user_ip, subnet):
                    lan_users.append({
                        'username': user.username,
                        'ip_address': user_ip,
                        'is_online': user.profile.is_online
                    })
            except Exception as e:
                self.stdout.write(self.style.WARNING(f'Error checking {user.username}: {e}'))
        
        # Display results
        if lan_users:
            self.stdout.write(self.style.SUCCESS(f'Found {len(lan_users)} users in your LAN:'))
            for user in lan_users:
                status = 'Online' if user['is_online'] else 'Offline'
                self.stdout.write(f"- {user['username']} ({user['ip_address']}): {status}")
        else:
            self.stdout.write(self.style.WARNING('No users found in your LAN.'))
    
    def get_local_ip(self):
        """Get local IP address"""
        try:
            # Try to get IP by creating a socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            # Fallback method
            try:
                interfaces = netifaces.interfaces()
                for interface in interfaces:
                    addrs = netifaces.ifaddresses(interface)
                    if netifaces.AF_INET in addrs:
                        for addr in addrs[netifaces.AF_INET]:
                            ip = addr['addr']
                            if ip != '127.0.0.1':
                                return ip
            except Exception:
                pass
            
            return '127.0.0.1'  # Default to localhost if all else fails
    
    def get_subnet(self, ip_address):
        """Get subnet for an IP address"""
        try:
            # Try to get network interfaces
            interfaces = netifaces.interfaces()
            for interface in interfaces:
                addrs = netifaces.ifaddresses(interface)
                if netifaces.AF_INET in addrs:
                    for addr in addrs[netifaces.AF_INET]:
                        if 'addr' in addr and addr['addr'] == ip_address and 'netmask' in addr:
                            import ipaddress
                            network = ipaddress.IPv4Network(f"{addr['addr']}/{addr['netmask']}", strict=False)
                            return str(network)
        except Exception:
            pass
        
        # Fallback to default class C subnet
        return ip_address.rsplit('.', 1)[0] + '.0/24'
    
    def is_in_subnet(self, ip_address, subnet):
        """Check if IP address is in subnet"""
        import ipaddress
        return ipaddress.IPv4Address(ip_address) in ipaddress.IPv4Network(subnet)
