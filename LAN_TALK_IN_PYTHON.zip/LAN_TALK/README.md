# LAN_TALK

A fully functional Django web application for offline LAN communication, featuring real-time messaging, voice/video calls, file sharing, and more.

## Features

- **User Authentication System**
  - Registration with username and password
  - Login and logout functionality
  - Password hashing using Django's built-in system
  - User profiles with status and online indicators

- **User Dashboard**
  - Display of online users in the LAN
  - Quick access buttons for chat, voice calls, and video calls
  - User profile management

- **Real-time Messaging**
  - WebSocket-based chat using Django Channels
  - Private messaging between users
  - Message timestamps and sender information
  - Real-time message delivery

- **Voice and Video Calls**
  - WebRTC integration for peer-to-peer communication
  - Both voice-only and video call options
  - Call controls (mute, video toggle, end call)
  - Signaling via WebSockets

- **LAN Discovery Feature**
  - Automatic detection of online users in the same subnet
  - Real-time online/offline status updates
  - IP-based user discovery

- **File Sharing System**
  - Upload and download interface
  - File expiration settings
  - Permission-based access control
  - File management

- **Admin Panel**
  - User management (ban, delete, promote)
  - File and chat monitoring
  - Basic analytics and statistics
  - System administration

- **Modern UI Design**
  - Bootstrap-based responsive layout
  - Mobile and desktop support
  - Offline-ready with local static assets

## Installation

### Prerequisites

- Python 3.8+
- pip (Python package manager)
- Git (optional)

### Setup Instructions

1. Clone or download this repository:
   ```
   git clone <repository-url>
   ```
   or extract the zip file to your desired location.

2. Navigate to the project directory:
   ```
   cd LAN_TALK
   ```

3. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

5. Apply database migrations:
   ```
   python manage.py migrate
   ```

6. Create a superuser (admin):
   ```
   python manage.py createsuperuser
   ```

7. Run the development server:
   ```
   python manage.py runserver 0.0.0.0:8000
   ```

8. Access the application:
   - Open a web browser and navigate to `http://localhost:8000`
   - From other devices in the LAN, use `http://<your-ip-address>:8000`

## LAN Deployment

For LAN deployment, follow these steps:

1. Ensure all devices are connected to the same local network.

2. Find your computer's IP address:
   - On Windows: Run `ipconfig` in Command Prompt
   - On macOS/Linux: Run `ifconfig` or `ip addr` in Terminal

3. Run the server with your IP address:
   ```
   python manage.py runserver 0.0.0.0:8000
   ```

4. Other users can access the application by entering `http://<your-ip-address>:8000` in their browsers.

5. For scanning users in your LAN:
   ```
   python manage.py scan_lan
   ```

## Configuration

The application uses environment variables for configuration. You can modify the `.env` file to change settings:

- `SECRET_KEY`: Django secret key
- `DEBUG`: Debug mode (True/False)
- `ALLOWED_HOSTS`: Comma-separated list of allowed hosts
- `STUN_SERVERS`: STUN servers for WebRTC (comma-separated)
- `MAX_UPLOAD_SIZE`: Maximum file upload size in MB

## Project Structure

```
LAN_TALK/
├── lan_talk/          # Project settings
├── users/             # User authentication and profiles
├── chat/              # Real-time messaging
├── core/              # Core functionality (calls, files, admin)
├── templates/         # HTML templates
├── static/            # Static files (CSS, JS, images)
├── media/             # User-uploaded files
├── venv/              # Virtual environment
├── .env               # Environment variables
├── manage.py          # Django management script
└── requirements.txt   # Python dependencies
```

## Usage

### User Registration and Login

1. Access the application and click "Register" to create a new account.
2. Fill in the registration form with your username, email, and password.
3. After registration, you'll be automatically logged in and redirected to the dashboard.
4. For subsequent visits, use the "Login" page with your credentials.

### Messaging

1. From the dashboard, view online users in your LAN.
2. Click on a user's "Chat" button to start or continue a conversation.
3. Type messages in the input field and press Enter or click the send button.
4. Messages are delivered in real-time and saved for future reference.

### Voice and Video Calls

1. From the dashboard or chat interface, click "Voice Call" or "Video Call" button.
2. Allow browser permissions for microphone and camera when prompted.
3. Wait for the connection to establish.
4. Use the call controls to mute audio, toggle video, or end the call.

### File Sharing

1. Navigate to the Files section from the navigation menu.
2. Click "Upload New File" to share a file.
3. Select a file, set expiration time, and choose users to share with.
4. Recipients can download shared files from their Files section.

### Admin Functions

1. Log in with an admin account (superuser or staff).
2. Access the admin dashboard from the navigation menu.
3. View statistics, manage users, monitor files, and administer chat rooms.

## Troubleshooting

### Connection Issues

- Ensure all devices are on the same local network.
- Check firewall settings to allow connections on the server port.
- Verify that the server is running with the correct IP address.

### WebRTC Problems

- Ensure your browser supports WebRTC (most modern browsers do).
- Allow camera and microphone permissions when prompted.
- For connection issues, try using different STUN servers in the .env file.

### Database Issues

- If you encounter database errors, try resetting the database:
  ```
  python manage.py flush
  python manage.py migrate
  python manage.py createsuperuser
  ```

## Security Considerations

- This application is designed for LAN use and doesn't implement all security measures needed for internet deployment.
- For internet-facing deployment, additional security measures would be required.
- Always use strong passwords for user accounts, especially admin accounts.

## License

This project is provided for educational and personal use.

## Credits

Developed as a comprehensive Django web application for LAN communication.
