from django.contrib import admin
from .models import CoreSettings

class CoreSettingsAdmin(admin.ModelAdmin):
    list_display = ('key', 'value', 'description')
    search_fields = ('key', 'description')

admin.site.register(CoreSettings, CoreSettingsAdmin)
