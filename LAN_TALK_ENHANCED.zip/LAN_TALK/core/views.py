from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

@login_required
def call_home(request):
    """
    View for call home page
    """
    # Get all online users except current user
    online_users = User.objects.filter(profile__is_online=True).exclude(id=request.user.id)
    
    context = {
        'online_users': online_users
    }
    return render(request, 'core/call_home.html', context)

@login_required
def voice_call(request, user_id):
    """
    View for voice call with a specific user
    """
    # Get the user to call or return 404
    call_user = get_object_or_404(User, id=user_id)
    
    context = {
        'call_user': call_user,
        'call_type': 'voice'
    }
    return render(request, 'core/call.html', context)

@login_required
def video_call(request, user_id):
    """
    View for video call with a specific user
    """
    # Get the user to call or return 404
    call_user = get_object_or_404(User, id=user_id)
    
    context = {
        'call_user': call_user,
        'call_type': 'video'
    }
    return render(request, 'core/call.html', context)
