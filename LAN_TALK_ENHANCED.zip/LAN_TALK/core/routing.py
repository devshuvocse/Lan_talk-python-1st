from django.urls import re_path
from . import consumers
from .lan_discovery import LANDiscoveryConsumer

websocket_urlpatterns = [
    re_path(r'ws/call/(?P<user_id>\w+)/$', consumers.CallSignalingConsumer.as_asgi()),
    re_path(r'ws/lan_discovery/$', LANDiscoveryConsumer.as_asgi()),
]
