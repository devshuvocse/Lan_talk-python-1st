import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth.models import User
import ipaddress
import socket
import netifaces

class LANDiscoveryConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.group_name = 'lan_discovery'
        
        # Join LAN discovery group
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        
        # Accept the connection
        await self.accept()
        
        # Update user's IP address and online status
        user = self.scope['user']
        if user.is_authenticated:
            # Get client IP address
            client_ip = self.get_client_ip()
            await self.update_user_ip(user.id, client_ip, True)
            
            # Broadcast user's online status to all clients
            await self.channel_layer.group_send(
                self.group_name,
                {
                    'type': 'user_online',
                    'user_id': user.id,
                    'username': user.username,
                    'ip_address': client_ip
                }
            )
            
            # Send current online users in LAN to the newly connected user
            online_users = await self.get_online_users_in_lan(client_ip)
            await self.send(text_data=json.dumps({
                'type': 'lan_users',
                'users': online_users
            }))
    
    async def disconnect(self, close_code):
        # Update user's online status
        user = self.scope['user']
        if user.is_authenticated:
            await self.update_user_ip(user.id, None, False)
            
            # Broadcast user's offline status
            await self.channel_layer.group_send(
                self.group_name,
                {
                    'type': 'user_offline',
                    'user_id': user.id,
                    'username': user.username
                }
            )
        
        # Leave LAN discovery group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )
    
    # Receive message from WebSocket
    async def receive(self, text_data):
        data = json.loads(text_data)
        message_type = data.get('type')
        
        if message_type == 'ping':
            # Respond to ping with pong
            await self.send(text_data=json.dumps({
                'type': 'pong',
                'timestamp': data.get('timestamp')
            }))
        
        elif message_type == 'scan_lan':
            # Scan LAN for online users
            client_ip = self.get_client_ip()
            online_users = await self.get_online_users_in_lan(client_ip)
            
            await self.send(text_data=json.dumps({
                'type': 'lan_users',
                'users': online_users
            }))
    
    # Handler for user online message
    async def user_online(self, event):
        user_id = event['user_id']
        username = event['username']
        ip_address = event['ip_address']
        
        # Send user online notification to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'user_online',
            'user_id': user_id,
            'username': username,
            'ip_address': ip_address
        }))
    
    # Handler for user offline message
    async def user_offline(self, event):
        user_id = event['user_id']
        username = event['username']
        
        # Send user offline notification to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'user_offline',
            'user_id': user_id,
            'username': username
        }))
    
    # Get client IP address
    def get_client_ip(self):
        x_forwarded_for = self.scope.get('headers', {}).get(b'x-forwarded-for')
        if x_forwarded_for:
            ip = x_forwarded_for.decode().split(',')[0]
        else:
            ip = self.scope.get('client', ['0.0.0.0'])[0]
        return ip
    
    # Get subnet for an IP address
    def get_subnet(self, ip_address):
        try:
            # Try to get network interfaces
            interfaces = netifaces.interfaces()
            for interface in interfaces:
                addrs = netifaces.ifaddresses(interface)
                if netifaces.AF_INET in addrs:
                    for addr in addrs[netifaces.AF_INET]:
                        if 'addr' in addr and 'netmask' in addr:
                            network = ipaddress.IPv4Network(f"{addr['addr']}/{addr['netmask']}", strict=False)
                            if ipaddress.IPv4Address(ip_address) in network:
                                return str(network)
        except Exception as e:
            print(f"Error determining subnet: {e}")
        
        # Fallback to default class C subnet
        try:
            ip_obj = ipaddress.IPv4Address(ip_address)
            if ip_obj.is_private:
                # Assume a /24 subnet for private IPs
                return f"{ip_address.rsplit('.', 1)[0]}.0/24"
        except Exception:
            pass
        
        return None
    
    @database_sync_to_async
    def update_user_ip(self, user_id, ip_address, is_online):
        try:
            user = User.objects.get(id=user_id)
            user.profile.ip_address = ip_address
            user.profile.is_online = is_online
            user.profile.save()
        except User.DoesNotExist:
            pass
    
    @database_sync_to_async
    def get_online_users_in_lan(self, client_ip):
        # Get subnet for client IP
        subnet = self.get_subnet(client_ip)
        if not subnet:
            return []
        
        # Get all online users
        online_users = []
        users = User.objects.filter(profile__is_online=True)
        
        for user in users:
            user_ip = user.profile.ip_address
            if user_ip:
                try:
                    # Check if user is in the same subnet
                    if subnet and ipaddress.IPv4Address(user_ip) in ipaddress.IPv4Network(subnet):
                        online_users.append({
                            'id': user.id,
                            'username': user.username,
                            'ip_address': user_ip,
                            'status': user.profile.status
                        })
                except Exception:
                    # If IP address is invalid, skip
                    pass
        
        return online_users
