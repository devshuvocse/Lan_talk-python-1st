from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import os
import uuid

class FileShare(models.Model):
    """Model for shared files in the LAN_TALK application"""
    
    # File information
    file = models.FileField(upload_to='shared_files/')
    original_filename = models.CharField(max_length=255)
    file_size = models.BigIntegerField()  # Size in bytes
    file_type = models.CharField(max_length=100)
    thumbnail = models.ImageField(upload_to='file_thumbnails/', null=True, blank=True)
    
    # Sharing details
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name='shared_files')
    shared_with = models.ManyToManyField(User, related_name='received_files', blank=True)
    is_public = models.BooleanField(default=False)  # If True, available to all LAN users
    
    # Timestamps
    uploaded_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    
    # Status
    is_deleted = models.BooleanField(default=False)
    
    # Metadata
    description = models.TextField(blank=True, null=True)
    tags = models.CharField(max_length=255, blank=True, null=True)
    
    def __str__(self):
        return f"{self.original_filename} (shared by {self.owner.username})"
    
    def is_expired(self):
        """Check if the file has expired"""
        if self.expires_at:
            return timezone.now() > self.expires_at
        return False
    
    def is_available_to(self, user):
        """Check if the file is available to a specific user"""
        if self.is_deleted or self.is_expired():
            return False
        
        if self.owner == user:
            return True
        
        if self.is_public:
            return True
        
        return self.shared_with.filter(id=user.id).exists()
    
    def get_file_extension(self):
        """Get the file extension"""
        _, ext = os.path.splitext(self.original_filename)
        return ext.lower()
    
    def get_file_type_category(self):
        """Categorize file type for UI display"""
        ext = self.get_file_extension()
        
        # Images
        if ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg']:
            return 'image'
        
        # Documents
        if ext in ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt', '.rtf', '.odt']:
            return 'document'
        
        # Videos
        if ext in ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.mkv', '.webm']:
            return 'video'
        
        # Audio
        if ext in ['.mp3', '.wav', '.ogg', '.m4a', '.flac', '.aac']:
            return 'audio'
        
        # Archives
        if ext in ['.zip', '.rar', '.7z', '.tar', '.gz']:
            return 'archive'
        
        # Code
        if ext in ['.py', '.js', '.html', '.css', '.java', '.cpp', '.c', '.php', '.rb', '.go', '.ts']:
            return 'code'
        
        # Other
        return 'other'
    
    def get_human_readable_size(self):
        """Convert file size to human-readable format"""
        size = self.file_size
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024 or unit == 'TB':
                return f"{size:.2f} {unit}"
            size /= 1024
    
    def save(self, *args, **kwargs):
        """Override save method to set file type"""
        if not self.pk:  # Only on creation
            # Set file type based on extension
            _, ext = os.path.splitext(self.original_filename)
            self.file_type = ext.lower().lstrip('.')
        
        super().save(*args, **kwargs)

class FileAccess(models.Model):
    """Model to track file access history"""
    
    file = models.ForeignKey(FileShare, on_delete=models.CASCADE, related_name='access_logs')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    accessed_at = models.DateTimeField(auto_now_add=True)
    access_type = models.CharField(max_length=20, choices=[
        ('view', 'Viewed'),
        ('download', 'Downloaded'),
        ('preview', 'Previewed'),
    ])
    
    def __str__(self):
        return f"{self.user.username} {self.access_type} {self.file.original_filename}"

class FileComment(models.Model):
    """Model for comments on shared files"""
    
    file = models.ForeignKey(FileShare, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Comment by {self.user.username} on {self.file.original_filename}"
