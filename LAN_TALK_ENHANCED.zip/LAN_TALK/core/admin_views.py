from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.db.models import Count, Q
from django.utils import timezone
from django.http import JsonResponse
from django.contrib import messages
from users.models import Profile
from chat.models import ChatRoom, Message, SharedFile
import datetime
import json

# Check if user is admin
def is_admin(user):
    return user.is_staff or user.is_superuser

@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    """
    Admin dashboard with analytics
    """
    # Get user statistics
    total_users = User.objects.count()
    active_users = User.objects.filter(profile__is_online=True).count()
    
    # Get chat statistics
    total_chats = ChatRoom.objects.count()
    total_messages = Message.objects.count()
    
    # Get file statistics
    total_files = SharedFile.objects.count()
    
    # Get user registration over time (last 7 days)
    today = timezone.now().date()
    date_range = [today - datetime.timedelta(days=i) for i in range(6, -1, -1)]
    
    user_registrations = []
    for date in date_range:
        count = User.objects.filter(
            date_joined__date=date
        ).count()
        user_registrations.append({
            'date': date.strftime('%Y-%m-%d'),
            'count': count
        })
    
    # Get message activity over time (last 7 days)
    message_activity = []
    for date in date_range:
        count = Message.objects.filter(
            timestamp__date=date
        ).count()
        message_activity.append({
            'date': date.strftime('%Y-%m-%d'),
            'count': count
        })
    
    context = {
        'total_users': total_users,
        'active_users': active_users,
        'total_chats': total_chats,
        'total_messages': total_messages,
        'total_files': total_files,
        'user_registrations': json.dumps(user_registrations),
        'message_activity': json.dumps(message_activity)
    }
    
    return render(request, 'core/admin/dashboard.html', context)

@login_required
@user_passes_test(is_admin)
def admin_users(request):
    """
    Admin user management
    """
    users = User.objects.all().order_by('-date_joined')
    
    context = {
        'users': users
    }
    
    return render(request, 'core/admin/users.html', context)

@login_required
@user_passes_test(is_admin)
def admin_ban_user(request, user_id):
    """
    Ban a user
    """
    if request.method == 'POST':
        user = get_object_or_404(User, id=user_id)
        
        # Don't allow banning yourself or other admins
        if user == request.user or user.is_staff or user.is_superuser:
            messages.error(request, "You cannot ban this user.")
            return redirect('admin_users')
        
        # Set user as inactive (banned)
        user.is_active = False
        user.save()
        
        # Update profile
        profile = Profile.objects.get(user=user)
        profile.is_online = False
        profile.status = "Banned"
        profile.save()
        
        messages.success(request, f"User {user.username} has been banned.")
        return redirect('admin_users')
    
    return redirect('admin_users')

@login_required
@user_passes_test(is_admin)
def admin_unban_user(request, user_id):
    """
    Unban a user
    """
    if request.method == 'POST':
        user = get_object_or_404(User, id=user_id)
        
        # Set user as active (unbanned)
        user.is_active = True
        user.save()
        
        # Update profile
        profile = Profile.objects.get(user=user)
        profile.status = "Available"
        profile.save()
        
        messages.success(request, f"User {user.username} has been unbanned.")
        return redirect('admin_users')
    
    return redirect('admin_users')

@login_required
@user_passes_test(is_admin)
def admin_delete_user(request, user_id):
    """
    Delete a user
    """
    if request.method == 'POST':
        user = get_object_or_404(User, id=user_id)
        
        # Don't allow deleting yourself or other admins
        if user == request.user or user.is_staff or user.is_superuser:
            messages.error(request, "You cannot delete this user.")
            return redirect('admin_users')
        
        username = user.username
        user.delete()
        
        messages.success(request, f"User {username} has been deleted.")
        return redirect('admin_users')
    
    return redirect('admin_users')

@login_required
@user_passes_test(is_admin)
def admin_make_admin(request, user_id):
    """
    Make a user an admin
    """
    if request.method == 'POST':
        user = get_object_or_404(User, id=user_id)
        
        # Make user staff
        user.is_staff = True
        user.save()
        
        messages.success(request, f"User {user.username} is now an admin.")
        return redirect('admin_users')
    
    return redirect('admin_users')

@login_required
@user_passes_test(is_admin)
def admin_remove_admin(request, user_id):
    """
    Remove admin status from a user
    """
    if request.method == 'POST':
        user = get_object_or_404(User, id=user_id)
        
        # Don't allow removing admin from yourself or superusers
        if user == request.user or user.is_superuser:
            messages.error(request, "You cannot remove admin status from this user.")
            return redirect('admin_users')
        
        # Remove staff status
        user.is_staff = False
        user.save()
        
        messages.success(request, f"Admin status removed from {user.username}.")
        return redirect('admin_users')
    
    return redirect('admin_users')

@login_required
@user_passes_test(is_admin)
def admin_files(request):
    """
    Admin file management
    """
    files = SharedFile.objects.all().order_by('-uploaded_at')
    
    context = {
        'files': files
    }
    
    return render(request, 'core/admin/files.html', context)

@login_required
@user_passes_test(is_admin)
def admin_delete_file(request, file_id):
    """
    Delete a file
    """
    if request.method == 'POST':
        shared_file = get_object_or_404(SharedFile, id=file_id)
        file_name = shared_file.name
        shared_file.delete()
        
        messages.success(request, f"File {file_name} has been deleted.")
        return redirect('admin_files')
    
    return redirect('admin_files')

@login_required
@user_passes_test(is_admin)
def admin_chats(request):
    """
    Admin chat management
    """
    chat_rooms = ChatRoom.objects.all().order_by('-created_at')
    
    context = {
        'chat_rooms': chat_rooms
    }
    
    return render(request, 'core/admin/chats.html', context)

@login_required
@user_passes_test(is_admin)
def admin_delete_chat(request, chat_id):
    """
    Delete a chat room
    """
    if request.method == 'POST':
        chat_room = get_object_or_404(ChatRoom, id=chat_id)
        chat_name = chat_room.name
        chat_room.delete()
        
        messages.success(request, f"Chat room {chat_name} has been deleted.")
        return redirect('admin_chats')
    
    return redirect('admin_chats')
