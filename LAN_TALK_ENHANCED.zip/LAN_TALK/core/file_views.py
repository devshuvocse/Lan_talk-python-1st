from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse, Http404
from django.contrib.auth.models import User
from django.utils import timezone
from django.conf import settings
from django.db.models import Q
from django.core.paginator import Paginator
from .models import FileShare, FileAccess, FileComment
import os
import uuid
import mimetypes
import json
from PIL import Image
import io
import zipfile
from datetime import timedelta

@login_required
def file_home(request):
    """Main file sharing dashboard view"""
    
    # Get query parameters
    file_type = request.GET.get('type', None)
    search_query = request.GET.get('q', None)
    sort_by = request.GET.get('sort', 'newest')
    filter_by = request.GET.get('filter', 'all')
    page = request.GET.get('page', 1)
    
    # Base queryset - files available to the user
    files_queryset = FileShare.objects.filter(
        Q(owner=request.user) |  # User's own files
        Q(shared_with=request.user) |  # Files shared with user
        Q(is_public=True)  # Public files
    ).filter(
        is_deleted=False
    ).distinct()
    
    # Apply file type filter
    if file_type:
        files_queryset = files_queryset.filter(file_type=file_type)
    
    # Apply search query
    if search_query:
        files_queryset = files_queryset.filter(
            Q(original_filename__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(tags__icontains=search_query)
        )
    
    # Apply filter
    if filter_by == 'my_files':
        files_queryset = files_queryset.filter(owner=request.user)
    elif filter_by == 'shared_with_me':
        files_queryset = files_queryset.filter(shared_with=request.user)
    elif filter_by == 'public':
        files_queryset = files_queryset.filter(is_public=True)
    
    # Apply sorting
    if sort_by == 'newest':
        files_queryset = files_queryset.order_by('-uploaded_at')
    elif sort_by == 'oldest':
        files_queryset = files_queryset.order_by('uploaded_at')
    elif sort_by == 'name_asc':
        files_queryset = files_queryset.order_by('original_filename')
    elif sort_by == 'name_desc':
        files_queryset = files_queryset.order_by('-original_filename')
    elif sort_by == 'size_asc':
        files_queryset = files_queryset.order_by('file_size')
    elif sort_by == 'size_desc':
        files_queryset = files_queryset.order_by('-file_size')
    
    # Paginate results
    paginator = Paginator(files_queryset, 20)  # 20 files per page
    files = paginator.get_page(page)
    
    # Get file type counts for filter UI
    file_type_counts = {
        'image': FileShare.objects.filter(
            Q(owner=request.user) | Q(shared_with=request.user) | Q(is_public=True),
            is_deleted=False,
            file_type__in=['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg']
        ).distinct().count(),
        
        'document': FileShare.objects.filter(
            Q(owner=request.user) | Q(shared_with=request.user) | Q(is_public=True),
            is_deleted=False,
            file_type__in=['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf', 'odt']
        ).distinct().count(),
        
        'video': FileShare.objects.filter(
            Q(owner=request.user) | Q(shared_with=request.user) | Q(is_public=True),
            is_deleted=False,
            file_type__in=['mp4', 'avi', 'mov', 'wmv', 'flv', 'mkv', 'webm']
        ).distinct().count(),
        
        'audio': FileShare.objects.filter(
            Q(owner=request.user) | Q(shared_with=request.user) | Q(is_public=True),
            is_deleted=False,
            file_type__in=['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac']
        ).distinct().count(),
        
        'archive': FileShare.objects.filter(
            Q(owner=request.user) | Q(shared_with=request.user) | Q(is_public=True),
            is_deleted=False,
            file_type__in=['zip', 'rar', '7z', 'tar', 'gz']
        ).distinct().count(),
    }
    
    # Get all users for sharing options
    all_users = User.objects.exclude(id=request.user.id)
    
    context = {
        'files': files,
        'file_type_counts': file_type_counts,
        'current_type': file_type,
        'current_search': search_query,
        'current_sort': sort_by,
        'current_filter': filter_by,
        'all_users': all_users,
    }
    
    return render(request, 'core/file_home.html', context)

@login_required
def upload_file(request):
    """Handle file upload"""
    if request.method == 'POST':
        # Check if file was uploaded
        if 'file' not in request.FILES:
            return JsonResponse({'status': 'error', 'message': 'No file was uploaded'})
        
        uploaded_file = request.FILES['file']
        
        # Get form data
        description = request.POST.get('description', '')
        tags = request.POST.get('tags', '')
        is_public = request.POST.get('is_public', 'false').lower() == 'true'
        
        # Get expiration (in hours, 0 means no expiration)
        try:
            expiration_hours = int(request.POST.get('expiration', 0))
        except ValueError:
            expiration_hours = 0
        
        # Calculate expiration date
        expires_at = None
        if expiration_hours > 0:
            expires_at = timezone.now() + timedelta(hours=expiration_hours)
        
        # Create file share object
        file_share = FileShare(
            file=uploaded_file,
            original_filename=uploaded_file.name,
            file_size=uploaded_file.size,
            owner=request.user,
            is_public=is_public,
            expires_at=expires_at,
            description=description,
            tags=tags
        )
        
        # Save to generate ID
        file_share.save()
        
        # Process shared_with users
        shared_with_ids = request.POST.get('shared_with', '')
        if shared_with_ids:
            try:
                user_ids = [int(uid) for uid in shared_with_ids.split(',')]
                users = User.objects.filter(id__in=user_ids)
                file_share.shared_with.add(*users)
            except ValueError:
                pass
        
        # Generate thumbnail for images
        if file_share.get_file_type_category() == 'image':
            try:
                img = Image.open(file_share.file)
                img.thumbnail((300, 300))
                thumb_io = io.BytesIO()
                img.save(thumb_io, format='JPEG')
                
                # Save thumbnail
                from django.core.files.base import ContentFile
                thumbnail_name = f"thumb_{file_share.id}.jpg"
                file_share.thumbnail.save(thumbnail_name, ContentFile(thumb_io.getvalue()), save=True)
            except Exception as e:
                print(f"Error generating thumbnail: {e}")
        
        return JsonResponse({
            'status': 'success',
            'file_id': file_share.id,
            'file_name': file_share.original_filename,
            'file_size': file_share.get_human_readable_size(),
            'file_type': file_share.get_file_type_category(),
            'uploaded_at': file_share.uploaded_at.strftime('%Y-%m-%d %H:%M:%S'),
            'expires_at': file_share.expires_at.strftime('%Y-%m-%d %H:%M:%S') if file_share.expires_at else None,
        })
    
    # GET request - show upload form
    return render(request, 'core/upload_file.html')

@login_required
def file_detail(request, file_id):
    """View file details"""
    file_share = get_object_or_404(FileShare, id=file_id)
    
    # Check if user has access
    if not file_share.is_available_to(request.user):
        raise Http404("File not found or you don't have permission to access it")
    
    # Log access
    FileAccess.objects.create(
        file=file_share,
        user=request.user,
        access_type='view'
    )
    
    # Get file comments
    comments = file_share.comments.all().order_by('created_at')
    
    # Get users who can access this file
    shared_with_users = file_share.shared_with.all()
    
    # Get all users for sharing options
    all_users = User.objects.exclude(id=request.user.id)
    
    context = {
        'file': file_share,
        'comments': comments,
        'shared_with_users': shared_with_users,
        'all_users': all_users,
        'is_owner': file_share.owner == request.user,
    }
    
    return render(request, 'core/file_detail.html', context)

@login_required
def download_file(request, file_id):
    """Download a file"""
    file_share = get_object_or_404(FileShare, id=file_id)
    
    # Check if user has access
    if not file_share.is_available_to(request.user):
        raise Http404("File not found or you don't have permission to access it")
    
    # Log access
    FileAccess.objects.create(
        file=file_share,
        user=request.user,
        access_type='download'
    )
    
    # Prepare file for download
    file_path = file_share.file.path
    
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type=mimetypes.guess_type(file_path)[0])
            response['Content-Disposition'] = f'attachment; filename="{file_share.original_filename}"'
            return response
    
    raise Http404("File not found")

@login_required
def preview_file(request, file_id):
    """Preview a file (for supported types)"""
    file_share = get_object_or_404(FileShare, id=file_id)
    
    # Check if user has access
    if not file_share.is_available_to(request.user):
        raise Http404("File not found or you don't have permission to access it")
    
    # Log access
    FileAccess.objects.create(
        file=file_share,
        user=request.user,
        access_type='preview'
    )
    
    # Prepare file for preview
    file_path = file_share.file.path
    
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type=mimetypes.guess_type(file_path)[0])
            response['Content-Disposition'] = f'inline; filename="{file_share.original_filename}"'
            return response
    
    raise Http404("File not found")

@login_required
def delete_file(request, file_id):
    """Delete a file (soft delete)"""
    if request.method == 'POST':
        file_share = get_object_or_404(FileShare, id=file_id)
        
        # Only owner can delete
        if file_share.owner != request.user:
            return JsonResponse({'status': 'error', 'message': 'You do not have permission to delete this file'})
        
        # Soft delete
        file_share.is_deleted = True
        file_share.save()
        
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
def update_file_sharing(request, file_id):
    """Update file sharing settings"""
    if request.method == 'POST':
        file_share = get_object_or_404(FileShare, id=file_id)
        
        # Only owner can update sharing settings
        if file_share.owner != request.user:
            return JsonResponse({'status': 'error', 'message': 'You do not have permission to update this file'})
        
        # Update public status
        is_public = request.POST.get('is_public', 'false').lower() == 'true'
        file_share.is_public = is_public
        
        # Update description and tags
        description = request.POST.get('description', '')
        tags = request.POST.get('tags', '')
        file_share.description = description
        file_share.tags = tags
        
        # Update expiration
        try:
            expiration_hours = int(request.POST.get('expiration', 0))
            if expiration_hours > 0:
                file_share.expires_at = timezone.now() + timedelta(hours=expiration_hours)
            else:
                file_share.expires_at = None
        except ValueError:
            pass
        
        # Save changes
        file_share.save()
        
        # Update shared users
        shared_with_ids = request.POST.get('shared_with', '')
        if shared_with_ids:
            # Clear existing shared users
            file_share.shared_with.clear()
            
            try:
                user_ids = [int(uid) for uid in shared_with_ids.split(',')]
                users = User.objects.filter(id__in=user_ids)
                file_share.shared_with.add(*users)
            except ValueError:
                pass
        else:
            # If no users specified, clear all
            file_share.shared_with.clear()
        
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
def add_comment(request, file_id):
    """Add a comment to a file"""
    if request.method == 'POST':
        file_share = get_object_or_404(FileShare, id=file_id)
        
        # Check if user has access
        if not file_share.is_available_to(request.user):
            return JsonResponse({'status': 'error', 'message': 'You do not have permission to comment on this file'})
        
        # Get comment content
        content = request.POST.get('content', '').strip()
        if not content:
            return JsonResponse({'status': 'error', 'message': 'Comment cannot be empty'})
        
        # Create comment
        comment = FileComment.objects.create(
            file=file_share,
            user=request.user,
            content=content
        )
        
        return JsonResponse({
            'status': 'success',
            'comment_id': comment.id,
            'user': comment.user.username,
            'content': comment.content,
            'created_at': comment.created_at.strftime('%Y-%m-%d %H:%M:%S'),
        })
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
def delete_comment(request, comment_id):
    """Delete a comment"""
    if request.method == 'POST':
        comment = get_object_or_404(FileComment, id=comment_id)
        
        # Only comment author or file owner can delete
        if comment.user != request.user and comment.file.owner != request.user:
            return JsonResponse({'status': 'error', 'message': 'You do not have permission to delete this comment'})
        
        # Delete comment
        comment.delete()
        
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
def bulk_download(request):
    """Download multiple files as a zip archive"""
    if request.method == 'POST':
        # Get file IDs from request
        file_ids = request.POST.getlist('file_ids[]')
        
        if not file_ids:
            return JsonResponse({'status': 'error', 'message': 'No files selected'})
        
        # Get files
        files = FileShare.objects.filter(id__in=file_ids)
        
        # Check access for each file
        accessible_files = [f for f in files if f.is_available_to(request.user)]
        
        if not accessible_files:
            return JsonResponse({'status': 'error', 'message': 'No accessible files selected'})
        
        # Create zip file
        zip_filename = f"lan_talk_files_{timezone.now().strftime('%Y%m%d_%H%M%S')}.zip"
        zip_path = os.path.join(settings.MEDIA_ROOT, zip_filename)
        
        with zipfile.ZipFile(zip_path, 'w') as zip_file:
            for file_share in accessible_files:
                # Log access
                FileAccess.objects.create(
                    file=file_share,
                    user=request.user,
                    access_type='download'
                )
                
                # Add file to zip
                file_path = file_share.file.path
                if os.path.exists(file_path):
                    zip_file.write(file_path, file_share.original_filename)
        
        # Serve zip file
        with open(zip_path, 'rb') as fh:
            response = HttpResponse(fh.read(), content_type='application/zip')
            response['Content-Disposition'] = f'attachment; filename="{zip_filename}"'
            
            # Delete temporary zip file
            os.remove(zip_path)
            
            return response
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
def file_gallery(request):
    """Gallery view for image files"""
    
    # Get only image files
    image_files = FileShare.objects.filter(
        Q(owner=request.user) | Q(shared_with=request.user) | Q(is_public=True),
        is_deleted=False,
        file_type__in=['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg']
    ).distinct().order_by('-uploaded_at')
    
    context = {
        'image_files': image_files,
    }
    
    return render(request, 'core/file_gallery.html', context)

@login_required
def file_stats(request):
    """View file statistics"""
    
    # Only show stats for user's own files
    user_files = FileShare.objects.filter(owner=request.user, is_deleted=False)
    
    # Total files
    total_files = user_files.count()
    
    # Total size
    total_size = sum(f.file_size for f in user_files)
    
    # Files by type
    files_by_type = {}
    for file_share in user_files:
        category = file_share.get_file_type_category()
        if category in files_by_type:
            files_by_type[category] += 1
        else:
            files_by_type[category] = 1
    
    # Most downloaded files
    most_downloaded = FileShare.objects.filter(
        owner=request.user,
        is_deleted=False,
        access_logs__access_type='download'
    ).annotate(
        download_count=models.Count('access_logs', filter=models.Q(access_logs__access_type='download'))
    ).order_by('-download_count')[:5]
    
    # Most viewed files
    most_viewed = FileShare.objects.filter(
        owner=request.user,
        is_deleted=False,
        access_logs__access_type__in=['view', 'preview']
    ).annotate(
        view_count=models.Count('access_logs', filter=models.Q(access_logs__access_type__in=['view', 'preview']))
    ).order_by('-view_count')[:5]
    
    context = {
        'total_files': total_files,
        'total_size': total_size,
        'human_readable_size': format_size(total_size),
        'files_by_type': files_by_type,
        'most_downloaded': most_downloaded,
        'most_viewed': most_viewed,
    }
    
    return render(request, 'core/file_stats.html', context)

def format_size(size_bytes):
    """Format file size in bytes to human-readable format"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024 or unit == 'TB':
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024
