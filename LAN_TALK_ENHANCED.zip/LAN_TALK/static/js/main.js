// Main JavaScript for LAN_TALK

// Global variables
let currentUser = null;
let onlineUsers = {};
let currentChatId = null;
let typingTimeout = null;
let lastTypingSignal = 0;
let unreadMessages = {};
let currentCallId = null;
let localStream = null;
let remoteStream = null;
let peerConnection = null;
let callSocket = null;
let mediaRecorder = null;
let recordedChunks = [];
let isCallActive = false;
let isMuted = false;
let isVideoOff = false;
let screenShareStream = null;
let isScreenSharing = false;

// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Get current user info
    const userElement = document.getElementById('current-user-data');
    if (userElement) {
        currentUser = {
            id: userElement.dataset.userId,
            username: userElement.dataset.username,
            avatar: userElement.dataset.avatar || null
        };
    }
    
    // Initialize message notifications
    initializeNotifications();
    
    // Initialize chat if on chat page
    if (document.getElementById('chat-container')) {
        initializeChat();
    }
    
    // Initialize call if on call page
    if (document.getElementById('call-container')) {
        initializeCall();
    }
    
    // Initialize dashboard if on dashboard page
    if (document.getElementById('dashboard-container')) {
        initializeDashboard();
    }
    
    // Initialize emoji picker buttons
    document.querySelectorAll('.emoji-picker-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.dataset.target;
            const targetInput = document.getElementById(targetId);
            
            if (targetInput) {
                showEmojiPicker(targetInput, this);
            }
        });
    });
    
    // Initialize file upload previews
    document.querySelectorAll('.custom-file-input').forEach(input => {
        input.addEventListener('change', function() {
            const fileName = this.files[0]?.name || 'No file chosen';
            const nextSibling = this.nextElementSibling;
            nextSibling.innerText = fileName;
            
            // Show preview if it's an image
            const previewElement = document.getElementById(this.dataset.preview);
            if (previewElement && this.files[0]) {
                const file = this.files[0];
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewElement.src = e.target.result;
                        previewElement.style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                } else {
                    previewElement.style.display = 'none';
                }
            }
        });
    });
    
    // Initialize dropdowns with search
    document.querySelectorAll('.dropdown-search-input').forEach(input => {
        input.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const dropdownMenu = this.closest('.dropdown-menu');
            
            dropdownMenu.querySelectorAll('.dropdown-item').forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
        
        // Prevent dropdown from closing when clicking on the search input
        input.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    });
    
    // Initialize copy to clipboard buttons
    document.querySelectorAll('.copy-to-clipboard').forEach(button => {
        button.addEventListener('click', function() {
            const textToCopy = this.dataset.clipboard;
            
            if (textToCopy) {
                navigator.clipboard.writeText(textToCopy).then(() => {
                    // Show success tooltip
                    const originalTitle = this.getAttribute('title');
                    const originalTrigger = this.getAttribute('data-bs-trigger');
                    
                    this.setAttribute('title', 'Copied!');
                    this.setAttribute('data-bs-trigger', 'manual');
                    
                    const tooltip = bootstrap.Tooltip.getInstance(this);
                    if (tooltip) {
                        tooltip.dispose();
                    }
                    
                    new bootstrap.Tooltip(this).show();
                    
                    setTimeout(() => {
                        this.setAttribute('title', originalTitle);
                        this.setAttribute('data-bs-trigger', originalTrigger);
                        
                        const newTooltip = bootstrap.Tooltip.getInstance(this);
                        if (newTooltip) {
                            newTooltip.dispose();
                        }
                        
                        new bootstrap.Tooltip(this);
                    }, 1000);
                }).catch(err => {
                    console.error('Failed to copy text: ', err);
                });
            }
        });
    });
    
    // Initialize confirmation dialogs
    document.querySelectorAll('[data-confirm]').forEach(element => {
        element.addEventListener('click', function(e) {
            const message = this.dataset.confirm || 'Are you sure?';
            
            if (!confirm(message)) {
                e.preventDefault();
                e.stopPropagation();
            }
        });
    });
});

// Initialize Notifications
function initializeNotifications() {
    // Check if browser supports notifications
    if ('Notification' in window) {
        // Request permission if not already granted
        if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
            document.getElementById('notification-permission-btn')?.addEventListener('click', function() {
                Notification.requestPermission().then(function(permission) {
                    if (permission === 'granted') {
                        showToast('Notifications enabled', 'You will now receive notifications when you receive new messages or calls.');
                    }
                });
            });
        }
    }
}

// Show toast notification
function showToast(title, message, duration = 5000) {
    const toast = document.getElementById('notification-toast');
    const toastTitle = document.getElementById('toast-title');
    const toastMessage = document.getElementById('toast-message');
    const toastTime = document.getElementById('toast-time');
    
    toastTitle.textContent = title;
    toastMessage.textContent = message;
    toastTime.textContent = 'Just now';
    
    const bsToast = new bootstrap.Toast(toast, {
        autohide: true,
        delay: duration
    });
    
    bsToast.show();
}

// Show browser notification
function showBrowserNotification(title, message, icon = null, clickCallback = null) {
    if ('Notification' in window && Notification.permission === 'granted') {
        const notification = new Notification(title, {
            body: message,
            icon: icon || '/static/img/logo.png'
        });
        
        if (clickCallback) {
            notification.onclick = clickCallback;
        }
    }
}

// Initialize Chat
function initializeChat() {
    const chatContainer = document.getElementById('chat-container');
    const chatMessages = document.getElementById('chat-messages');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-message-btn');
    const chatId = chatContainer.dataset.chatId;
    const recipientId = chatContainer.dataset.recipientId;
    
    currentChatId = chatId;
    
    // Connect to WebSocket
    const chatSocket = new WebSocket(
        'ws://' + window.location.host + '/ws/chat/' + chatId + '/'
    );
    
    chatSocket.onmessage = function(e) {
        const data = JSON.parse(e.data);
        
        if (data.type === 'chat_message') {
            // Add message to chat
            addMessageToChat(data.message);
            
            // Scroll to bottom
            scrollToBottom(chatMessages);
            
            // Mark as read if from other user
            if (data.message.sender_id !== currentUser.id) {
                chatSocket.send(JSON.stringify({
                    'type': 'mark_read',
                    'message_id': data.message.id
                }));
                
                // Send browser notification if not focused
                if (!document.hasFocus()) {
                    showBrowserNotification(
                        data.message.sender_name,
                        data.message.content,
                        data.message.sender_avatar,
                        function() {
                            window.focus();
                            window.location.href = '/chat/' + chatId + '/';
                        }
                    );
                }
            }
        }
        else if (data.type === 'typing_indicator') {
            // Show typing indicator
            const typingIndicator = document.getElementById('typing-indicator');
            
            if (data.is_typing && data.user_id !== currentUser.id) {
                typingIndicator.style.display = 'flex';
            } else {
                typingIndicator.style.display = 'none';
            }
        }
        else if (data.type === 'message_reaction') {
            // Update message reaction
            updateMessageReaction(data.message_id, data.reaction, data.user_id, data.user_name);
        }
        else if (data.type === 'message_read') {
            // Update read status
            updateMessageReadStatus(data.message_ids);
        }
        else if (data.type === 'message_history') {
            // Load message history
            data.messages.forEach(message => {
                addMessageToChat(message, false);
            });
            
            // Scroll to bottom
            scrollToBottom(chatMessages);
            
            // Mark all as read
            const unreadMessages = data.messages.filter(
                message => message.sender_id !== currentUser.id && !message.is_read
            ).map(message => message.id);
            
            if (unreadMessages.length > 0) {
                chatSocket.send(JSON.stringify({
                    'type': 'mark_read',
                    'message_ids': unreadMessages
                }));
            }
        }
    };
    
    chatSocket.onclose = function(e) {
        console.error('Chat socket closed unexpectedly');
    };
    
    // Send message
    function sendMessage() {
        const message = messageInput.value.trim();
        
        if (message) {
            chatSocket.send(JSON.stringify({
                'type': 'chat_message',
                'message': message
            }));
            
            messageInput.value = '';
            
            // Clear typing indicator
            clearTimeout(typingTimeout);
            chatSocket.send(JSON.stringify({
                'type': 'typing_indicator',
                'is_typing': false
            }));
        }
    }
    
    // Send button click
    sendButton.addEventListener('click', function() {
        sendMessage();
        messageInput.focus();
    });
    
    // Enter key press
    messageInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Typing indicator
    messageInput.addEventListener('input', function() {
        // Don't send typing indicator too frequently
        const now = Date.now();
        if (now - lastTypingSignal > 2000) {
            chatSocket.send(JSON.stringify({
                'type': 'typing_indicator',
                'is_typing': true
            }));
            
            lastTypingSignal = now;
        }
        
        // Clear previous timeout
        clearTimeout(typingTimeout);
        
        // Set new timeout to clear typing indicator
        typingTimeout = setTimeout(function() {
            chatSocket.send(JSON.stringify({
                'type': 'typing_indicator',
                'is_typing': false
            }));
        }, 3000);
    });
    
    // File upload
    const fileInput = document.getElementById('file-input');
    const fileButton = document.getElementById('file-upload-btn');
    
    fileButton.addEventListener('click', function() {
        fileInput.click();
    });
    
    fileInput.addEventListener('change', function() {
        if (this.files.length > 0) {
            const file = this.files[0];
            
            // Check file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) {
                showToast('Error', 'File size exceeds 10MB limit.');
                return;
            }
            
            // Create FormData
            const formData = new FormData();
            formData.append('file', file);
            formData.append('chat_id', chatId);
            
            // Show upload progress
            const progressContainer = document.createElement('div');
            progressContainer.className = 'upload-progress';
            progressContainer.innerHTML = `
                <div class="upload-progress-info">
                    <div class="upload-filename">${file.name}</div>
                    <div class="upload-progress-bar">
                        <div class="upload-progress-fill" style="width: 0%"></div>
                    </div>
                </div>
                <div class="upload-progress-status">0%</div>
            `;
            
            chatMessages.appendChild(progressContainer);
            scrollToBottom(chatMessages);
            
            // Upload file
            const xhr = new XMLHttpRequest();
            xhr.open('POST', '/chat/upload-file/');
            
            // CSRF token
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            xhr.setRequestHeader('X-CSRFToken', csrfToken);
            
            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressContainer.querySelector('.upload-progress-fill').style.width = percent + '%';
                    progressContainer.querySelector('.upload-progress-status').textContent = percent + '%';
                }
            });
            
            xhr.addEventListener('load', function() {
                if (xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        
                        if (response.status === 'success') {
                            // Remove progress container
                            progressContainer.remove();
                            
                            // Send file message
                            chatSocket.send(JSON.stringify({
                                'type': 'chat_message',
                                'message': `[file]${response.file_url}[/file]${response.file_name}`
                            }));
                        } else {
                            progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                            progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                            
                            setTimeout(() => {
                                progressContainer.remove();
                            }, 3000);
                            
                            showToast('Error', response.message || 'Failed to upload file.');
                        }
                    } catch (error) {
                        console.error('Error parsing response:', error);
                        progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                        progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                        
                        setTimeout(() => {
                            progressContainer.remove();
                        }, 3000);
                        
                        showToast('Error', 'Failed to upload file.');
                    }
                } else {
                    progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                    progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                    
                    setTimeout(() => {
                        progressContainer.remove();
                    }, 3000);
                    
                    showToast('Error', 'Failed to upload file.');
                }
                
                // Reset file input
                fileInput.value = '';
            });
            
            xhr.addEventListener('error', function() {
                progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                
                setTimeout(() => {
                    progressContainer.remove();
                }, 3000);
                
                showToast('Error', 'Failed to upload file.');
                
                // Reset file input
                fileInput.value = '';
            });
            
            xhr.send(formData);
        }
    });
    
    // Emoji picker
    const emojiButton = document.getElementById('emoji-btn');
    
    emojiButton.addEventListener('click', function() {
        showEmojiPicker(messageInput, this);
    });
    
    // Voice message recording
    const recordButton = document.getElementById('voice-record-btn');
    
    if (recordButton) {
        let isRecording = false;
        let mediaRecorder = null;
        let recordedChunks = [];
        let recordingStartTime = 0;
        let recordingTimer = null;
        
        recordButton.addEventListener('click', function() {
            if (!isRecording) {
                // Start recording
                navigator.mediaDevices.getUserMedia({ audio: true })
                    .then(stream => {
                        isRecording = true;
                        recordButton.classList.add('recording');
                        recordButton.innerHTML = '<i class="bi bi-stop-fill"></i>';
                        
                        // Show recording indicator
                        const recordingIndicator = document.createElement('div');
                        recordingIndicator.id = 'recording-indicator';
                        recordingIndicator.className = 'recording-indicator';
                        recordingIndicator.innerHTML = `
                            <div class="recording-indicator-dot"></div>
                            <span class="recording-time">0:00</span>
                        `;
                        
                        document.querySelector('.chat-input-container').appendChild(recordingIndicator);
                        
                        // Start timer
                        recordingStartTime = Date.now();
                        recordingTimer = setInterval(() => {
                            const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
                            const minutes = Math.floor(elapsed / 60);
                            const seconds = elapsed % 60;
                            
                            document.querySelector('.recording-time').textContent = 
                                `${minutes}:${seconds.toString().padStart(2, '0')}`;
                            
                            // Limit recording to 5 minutes
                            if (elapsed >= 300) {
                                stopRecording();
                            }
                        }, 1000);
                        
                        // Create MediaRecorder
                        mediaRecorder = new MediaRecorder(stream);
                        recordedChunks = [];
                        
                        mediaRecorder.addEventListener('dataavailable', function(e) {
                            if (e.data.size > 0) {
                                recordedChunks.push(e.data);
                            }
                        });
                        
                        mediaRecorder.addEventListener('stop', function() {
                            // Create blob from recorded chunks
                            const blob = new Blob(recordedChunks, { type: 'audio/webm' });
                            
                            // Create FormData
                            const formData = new FormData();
                            formData.append('file', blob, 'voice-message.webm');
                            formData.append('chat_id', chatId);
                            formData.append('type', 'voice');
                            
                            // Show upload progress
                            const progressContainer = document.createElement('div');
                            progressContainer.className = 'upload-progress';
                            progressContainer.innerHTML = `
                                <div class="upload-progress-info">
                                    <div class="upload-filename">Voice Message</div>
                                    <div class="upload-progress-bar">
                                        <div class="upload-progress-fill" style="width: 0%"></div>
                                    </div>
                                </div>
                                <div class="upload-progress-status">0%</div>
                            `;
                            
                            chatMessages.appendChild(progressContainer);
                            scrollToBottom(chatMessages);
                            
                            // Upload file
                            const xhr = new XMLHttpRequest();
                            xhr.open('POST', '/chat/upload-file/');
                            
                            // CSRF token
                            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                            xhr.setRequestHeader('X-CSRFToken', csrfToken);
                            
                            xhr.upload.addEventListener('progress', function(e) {
                                if (e.lengthComputable) {
                                    const percent = Math.round((e.loaded / e.total) * 100);
                                    progressContainer.querySelector('.upload-progress-fill').style.width = percent + '%';
                                    progressContainer.querySelector('.upload-progress-status').textContent = percent + '%';
                                }
                            });
                            
                            xhr.addEventListener('load', function() {
                                if (xhr.status === 200) {
                                    try {
                                        const response = JSON.parse(xhr.responseText);
                                        
                                        if (response.status === 'success') {
                                            // Remove progress container
                                            progressContainer.remove();
                                            
                                            // Send voice message
                                            chatSocket.send(JSON.stringify({
                                                'type': 'chat_message',
                                                'message': `[voice]${response.file_url}[/voice]`
                                            }));
                                        } else {
                                            progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                                            progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                                            
                                            setTimeout(() => {
                                                progressContainer.remove();
                                            }, 3000);
                                            
                                            showToast('Error', response.message || 'Failed to upload voice message.');
                                        }
                                    } catch (error) {
                                        console.error('Error parsing response:', error);
                                        progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                                        progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                                        
                                        setTimeout(() => {
                                            progressContainer.remove();
                                        }, 3000);
                                        
                                        showToast('Error', 'Failed to upload voice message.');
                                    }
                                } else {
                                    progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                                    progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                                    
                                    setTimeout(() => {
                                        progressContainer.remove();
                                    }, 3000);
                                    
                                    showToast('Error', 'Failed to upload voice message.');
                                }
                            });
                            
                            xhr.addEventListener('error', function() {
                                progressContainer.querySelector('.upload-progress-status').textContent = 'Failed';
                                progressContainer.querySelector('.upload-progress-status').classList.add('text-danger');
                                
                                setTimeout(() => {
                                    progressContainer.remove();
                                }, 3000);
                                
                                showToast('Error', 'Failed to upload voice message.');
                            });
                            
                            xhr.send(formData);
                            
                            // Stop all tracks
                            stream.getTracks().forEach(track => track.stop());
                        });
                        
                        // Start recording
                        mediaRecorder.start();
                    })
                    .catch(err => {
                        console.error('Error accessing microphone:', err);
                        showToast('Error', 'Could not access microphone. Please check permissions.');
                    });
            } else {
                // Stop recording
                stopRecording();
            }
        });
        
        function stopRecording() {
            if (isRecording && mediaRecorder) {
                isRecording = false;
                recordButton.classList.remove('recording');
                recordButton.innerHTML = '<i class="bi bi-mic"></i>';
                
                // Remove recording indicator
                document.getElementById('recording-indicator')?.remove();
                
                // Stop timer
                clearInterval(recordingTimer);
                
                // Stop recording
                mediaRecorder.stop();
            }
        }
        
        // Cancel recording on Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && isRecording) {
                isRecording = false;
                recordButton.classList.remove('recording');
                recordButton.innerHTML = '<i class="bi bi-mic"></i>';
                
                // Remove recording indicator
                document.getElementById('recording-indicator')?.remove();
                
                // Stop timer
                clearInterval(recordingTimer);
                
                // Stop recording and discard
                mediaRecorder.stop();
                recordedChunks = [];
                
                showToast('Info', 'Voice recording cancelled.');
            }
        });
    }
    
    // Call buttons
    const voiceCallBtn = document.getElementById('voice-call-btn');
    const videoCallBtn = document.getElementById('video-call-btn');
    
    if (voiceCallBtn) {
        voiceCallBtn.addEventListener('click', function() {
            window.location.href = `/call/${recipientId}/?type=voice`;
        });
    }
    
    if (videoCallBtn) {
        videoCallBtn.addEventListener('click', function() {
            window.location.href = `/call/${recipientId}/?type=video`;
        });
    }
    
    // Message reactions
    chatMessages.addEventListener('click', function(e) {
        const reactionButton = e.target.closest('.message-reaction-btn');
        
        if (reactionButton) {
            const messageId = reactionButton.closest('.chat-message').dataset.id;
            const reaction = reactionButton.dataset.reaction;
            
            chatSocket.send(JSON.stringify({
                'type': 'message_reaction',
                'message_id': messageId,
                'reaction': reaction
            }));
        }
    });
    
    // Add message to chat
    function addMessageToChat(message, animate = true) {
        const isOutgoing = message.sender_id === currentUser.id;
        const messageElement = document.createElement('div');
        messageElement.className = `chat-message ${isOutgoing ? 'outgoing' : 'incoming'}`;
        messageElement.dataset.id = message.id;
        
        // Format timestamp
        const timestamp = new Date(message.timestamp);
        const formattedTime = timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const formattedDate = timestamp.toLocaleDateString([], { month: 'short', day: 'numeric' });
        
        // Check if message contains file
        let messageContent = message.content;
        let fileHtml = '';
        
        // File message
        const fileMatch = messageContent.match(/\[file\](.*?)\[\/file\](.*)/);
        if (fileMatch) {
            const fileUrl = fileMatch[1];
            const fileName = fileMatch[2];
            const fileExt = fileName.split('.').pop().toLowerCase();
            
            // Determine file type
            let fileIcon = 'bi-file-earmark';
            if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-image';
            } else if (['mp4', 'webm', 'mov', 'avi'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-play';
            } else if (['mp3', 'wav', 'ogg'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-music';
            } else if (['pdf'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-pdf';
            } else if (['doc', 'docx'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-word';
            } else if (['xls', 'xlsx'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-excel';
            } else if (['ppt', 'pptx'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-slides';
            } else if (['zip', 'rar', '7z'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-zip';
            } else if (['txt', 'md'].includes(fileExt)) {
                fileIcon = 'bi-file-earmark-text';
            }
            
            // Create file preview
            if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExt)) {
                fileHtml = `
                    <div class="message-file message-image">
                        <a href="${fileUrl}" target="_blank">
                            <img src="${fileUrl}" alt="${fileName}" class="message-image-preview">
                        </a>
                        <div class="message-file-info">
                            <span class="message-file-name">${fileName}</span>
                            <a href="${fileUrl}" download="${fileName}" class="message-file-download">
                                <i class="bi bi-download"></i>
                            </a>
                        </div>
                    </div>
                `;
            } else if (['mp4', 'webm'].includes(fileExt)) {
                fileHtml = `
                    <div class="message-file message-video">
                        <video controls class="message-video-preview">
                            <source src="${fileUrl}" type="video/${fileExt}">
                            Your browser does not support the video tag.
                        </video>
                        <div class="message-file-info">
                            <span class="message-file-name">${fileName}</span>
                            <a href="${fileUrl}" download="${fileName}" class="message-file-download">
                                <i class="bi bi-download"></i>
                            </a>
                        </div>
                    </div>
                `;
            } else if (['mp3', 'wav', 'ogg'].includes(fileExt)) {
                fileHtml = `
                    <div class="message-file message-audio">
                        <audio controls class="message-audio-preview">
                            <source src="${fileUrl}" type="audio/${fileExt}">
                            Your browser does not support the audio tag.
                        </audio>
                        <div class="message-file-info">
                            <span class="message-file-name">${fileName}</span>
                            <a href="${fileUrl}" download="${fileName}" class="message-file-download">
                                <i class="bi bi-download"></i>
                            </a>
                        </div>
                    </div>
                `;
            } else {
                fileHtml = `
                    <div class="message-file">
                        <div class="message-file-icon">
                            <i class="bi ${fileIcon}"></i>
                        </div>
                        <div class="message-file-info">
                            <span class="message-file-name">${fileName}</span>
                            <a href="${fileUrl}" download="${fileName}" class="message-file-download">
                                <i class="bi bi-download"></i>
                            </a>
                        </div>
                    </div>
                `;
            }
            
            messageContent = '';
        }
        
        // Voice message
        const voiceMatch = messageContent.match(/\[voice\](.*?)\[\/voice\]/);
        if (voiceMatch) {
            const voiceUrl = voiceMatch[1];
            
            fileHtml = `
                <div class="message-file message-voice">
                    <audio controls class="message-voice-preview">
                        <source src="${voiceUrl}" type="audio/webm">
                        Your browser does not support the audio tag.
                    </audio>
                    <div class="message-file-info">
                        <span class="message-file-name">Voice Message</span>
                        <a href="${voiceUrl}" download="voice-message.webm" class="message-file-download">
                            <i class="bi bi-download"></i>
                        </a>
                    </div>
                </div>
            `;
            
            messageContent = '';
        }
        
        // Create message HTML
        let messageHtml = '';
        
        if (!isOutgoing) {
            messageHtml += `
                <div class="chat-message-avatar">
                    <div class="avatar avatar-sm">
                        ${message.sender_avatar ? 
                            `<img src="${message.sender_avatar}" alt="${message.sender_name}">` : 
                            message.sender_name.charAt(0).toUpperCase()
                        }
                    </div>
                </div>
            `;
        }
        
        messageHtml += `
            <div class="chat-message-content">
                ${!isOutgoing ? `<div class="chat-message-name">${message.sender_name}</div>` : ''}
                <div class="chat-message-bubble">
                    ${messageContent ? `<p class="chat-message-text">${messageContent}</p>` : ''}
                    ${fileHtml}
                </div>
                <div class="chat-message-info">
                    <span class="chat-message-time" title="${formattedDate}">${formattedTime}</span>
                    ${isOutgoing ? `
                        <span class="chat-message-status">
                            <i class="bi ${message.is_read ? 'bi-check-all' : 'bi-check'} chat-message-status-icon"></i>
                        </span>
                    ` : ''}
                </div>
                <div class="chat-message-reactions" data-message-id="${message.id}">
                    ${message.reactions ? renderReactions(message.reactions) : ''}
                </div>
                <div class="chat-message-actions">
                    <div class="chat-message-action-btn message-reaction-btn" data-reaction="👍" title="Like">
                        <i class="bi bi-hand-thumbs-up"></i>
                    </div>
                    <div class="chat-message-action-btn message-reaction-btn" data-reaction="❤️" title="Love">
                        <i class="bi bi-heart"></i>
                    </div>
                    <div class="chat-message-action-btn message-reaction-btn" data-reaction="😂" title="Laugh">
                        <i class="bi bi-emoji-laughing"></i>
                    </div>
                    <div class="chat-message-action-btn message-reaction-btn" data-reaction="😮" title="Wow">
                        <i class="bi bi-emoji-surprise"></i>
                    </div>
                    <div class="chat-message-action-btn message-reaction-btn" data-reaction="😢" title="Sad">
                        <i class="bi bi-emoji-frown"></i>
                    </div>
                </div>
            </div>
        `;
        
        if (isOutgoing) {
            messageHtml += `
                <div class="chat-message-avatar">
                    <div class="avatar avatar-sm">
                        ${currentUser.avatar ? 
                            `<img src="${currentUser.avatar}" alt="${currentUser.username}">` : 
                            currentUser.username.charAt(0).toUpperCase()
                        }
                    </div>
                </div>
            `;
        }
        
        messageElement.innerHTML = messageHtml;
        
        // Add animation class if needed
        if (animate) {
            messageElement.classList.add('message-appear');
        }
        
        // Add to chat
        chatMessages.appendChild(messageElement);
    }
    
    // Render reactions
    function renderReactions(reactions) {
        let html = '';
        
        for (const reaction in reactions) {
            if (reactions[reaction].length > 0) {
                html += `
                    <div class="chat-message-reaction">
                        <span class="chat-message-reaction-emoji">${reaction}</span>
                        <span class="chat-message-reaction-count">${reactions[reaction].length}</span>
                    </div>
                `;
            }
        }
        
        return html;
    }
    
    // Update message reaction
    function updateMessageReaction(messageId, reaction, userId, userName) {
        const messageReactions = document.querySelector(`.chat-message[data-id="${messageId}"] .chat-message-reactions`);
        
        if (messageReactions) {
            // Fetch current reactions
            fetch(`/chat/message/${messageId}/reactions/`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        messageReactions.innerHTML = renderReactions(data.reactions);
                    }
                })
                .catch(error => {
                    console.error('Error fetching reactions:', error);
                });
        }
    }
    
    // Update message read status
    function updateMessageReadStatus(messageIds) {
        messageIds.forEach(messageId => {
            const messageStatus = document.querySelector(`.chat-message[data-id="${messageId}"] .chat-message-status-icon`);
            
            if (messageStatus) {
                messageStatus.classList.remove('bi-check');
                messageStatus.classList.add('bi-check-all');
            }
        });
    }
    
    // Scroll to bottom of chat
    function scrollToBottom(element) {
        element.scrollTop = element.scrollHeight;
    }
    
    // Initial scroll to bottom
    scrollToBottom(chatMessages);
}

// Initialize Call
function initializeCall() {
    const callContainer = document.getElementById('call-container');
    const localVideo = document.getElementById('local-video');
    const remoteVideo = document.getElementById('remote-video');
    const callStatus = document.getElementById('call-status');
    const callDuration = document.getElementById('call-duration');
    const muteBtn = document.getElementById('mute-btn');
    const videoBtn = document.getElementById('video-btn');
    const screenShareBtn = document.getElementById('screen-share-btn');
    const endCallBtn = document.getElementById('end-call-btn');
    
    const recipientId = callContainer.dataset.recipientId;
    const callType = callContainer.dataset.callType || 'voice';
    const callId = callContainer.dataset.callId || generateCallId();
    
    currentCallId = callId;
    isCallActive = false;
    isMuted = false;
    isVideoOff = callType === 'voice';
    isScreenSharing = false;
    
    let callStartTime = null;
    let durationInterval = null;
    
    // Connect to WebSocket
    callSocket = new WebSocket(
        'ws://' + window.location.host + '/ws/call/' + recipientId + '/'
    );
    
    callSocket.onmessage = function(e) {
        const data = JSON.parse(e.data);
        
        if (data.type === 'offer') {
            handleOffer(data.offer);
        }
        else if (data.type === 'answer') {
            handleAnswer(data.answer);
        }
        else if (data.type === 'candidate') {
            handleCandidate(data.candidate);
        }
        else if (data.type === 'call_accepted') {
            handleCallAccepted();
        }
        else if (data.type === 'call_declined') {
            handleCallDeclined(data.reason);
        }
        else if (data.type === 'call_ended') {
            handleCallEnded(data.reason);
        }
    };
    
    callSocket.onopen = function(e) {
        // Initialize WebRTC
        initializeWebRTC();
        
        // Start call
        startCall();
    };
    
    callSocket.onclose = function(e) {
        console.error('Call socket closed unexpectedly');
        
        // End call if active
        if (isCallActive) {
            endCall('Connection lost');
        } else {
            // Redirect to dashboard
            window.location.href = '/dashboard/';
        }
    };
    
    // Initialize WebRTC
    function initializeWebRTC() {
        // Create peer connection
        const configuration = {
            iceServers: [
                { urls: 'stun:stun.l.google.com:19302' },
                { urls: 'stun:stun1.l.google.com:19302' }
            ]
        };
        
        peerConnection = new RTCPeerConnection(configuration);
        
        // Add event handlers
        peerConnection.onicecandidate = function(e) {
            if (e.candidate) {
                callSocket.send(JSON.stringify({
                    'type': 'candidate',
                    'candidate': e.candidate
                }));
            }
        };
        
        peerConnection.ontrack = function(e) {
            remoteStream = e.streams[0];
            remoteVideo.srcObject = remoteStream;
        };
        
        peerConnection.oniceconnectionstatechange = function(e) {
            if (peerConnection.iceConnectionState === 'disconnected' || 
                peerConnection.iceConnectionState === 'failed' || 
                peerConnection.iceConnectionState === 'closed') {
                
                endCall('Connection lost');
            }
        };
    }
    
    // Start call
    function startCall() {
        // Get user media
        const constraints = {
            audio: true,
            video: callType === 'video'
        };
        
        navigator.mediaDevices.getUserMedia(constraints)
            .then(stream => {
                localStream = stream;
                localVideo.srcObject = stream;
                
                // Add tracks to peer connection
                localStream.getTracks().forEach(track => {
                    peerConnection.addTrack(track, localStream);
                });
                
                // Update UI
                updateCallUI();
                
                // Create and send offer
                peerConnection.createOffer()
                    .then(offer => {
                        return peerConnection.setLocalDescription(offer);
                    })
                    .then(() => {
                        callSocket.send(JSON.stringify({
                            'type': 'offer',
                            'offer': peerConnection.localDescription,
                            'call_id': callId,
                            'call_type': callType
                        }));
                        
                        // Update call status
                        callStatus.textContent = 'Calling...';
                    })
                    .catch(error => {
                        console.error('Error creating offer:', error);
                        endCall('Failed to create offer');
                    });
            })
            .catch(error => {
                console.error('Error accessing media devices:', error);
                
                if (error.name === 'NotAllowedError') {
                    endCall('Media access denied');
                } else {
                    endCall('Failed to access media devices');
                }
            });
    }
    
    // Handle offer
    function handleOffer(offer) {
        peerConnection.setRemoteDescription(new RTCSessionDescription(offer))
            .then(() => {
                return peerConnection.createAnswer();
            })
            .then(answer => {
                return peerConnection.setLocalDescription(answer);
            })
            .then(() => {
                callSocket.send(JSON.stringify({
                    'type': 'answer',
                    'answer': peerConnection.localDescription
                }));
                
                // Call is now active
                isCallActive = true;
                
                // Start call timer
                startCallTimer();
                
                // Update call status
                callStatus.textContent = 'Connected';
            })
            .catch(error => {
                console.error('Error handling offer:', error);
                endCall('Failed to handle offer');
            });
    }
    
    // Handle answer
    function handleAnswer(answer) {
        peerConnection.setRemoteDescription(new RTCSessionDescription(answer))
            .then(() => {
                // Call is now active
                isCallActive = true;
                
                // Start call timer
                startCallTimer();
                
                // Update call status
                callStatus.textContent = 'Connected';
            })
            .catch(error => {
                console.error('Error handling answer:', error);
                endCall('Failed to handle answer');
            });
    }
    
    // Handle ICE candidate
    function handleCandidate(candidate) {
        peerConnection.addIceCandidate(new RTCIceCandidate(candidate))
            .catch(error => {
                console.error('Error adding ICE candidate:', error);
            });
    }
    
    // Handle call accepted
    function handleCallAccepted() {
        // Update call status
        callStatus.textContent = 'Call accepted, connecting...';
    }
    
    // Handle call declined
    function handleCallDeclined(reason) {
        endCall(reason || 'Call declined');
    }
    
    // Handle call ended
    function handleCallEnded(reason) {
        endCall(reason || 'Call ended by other user');
    }
    
    // End call
    function endCall(reason) {
        // Stop call timer
        stopCallTimer();
        
        // Close peer connection
        if (peerConnection) {
            peerConnection.close();
            peerConnection = null;
        }
        
        // Stop local stream
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
            localStream = null;
        }
        
        // Stop screen share stream
        if (screenShareStream) {
            screenShareStream.getTracks().forEach(track => track.stop());
            screenShareStream = null;
        }
        
        // Update call status
        callStatus.textContent = reason || 'Call ended';
        
        // Show call ended UI
        callContainer.classList.add('call-ended');
        
        // Redirect after delay
        setTimeout(() => {
            window.location.href = '/dashboard/';
        }, 3000);
    }
    
    // Start call timer
    function startCallTimer() {
        callStartTime = Date.now();
        
        durationInterval = setInterval(() => {
            const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            
            callDuration.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        }, 1000);
    }
    
    // Stop call timer
    function stopCallTimer() {
        clearInterval(durationInterval);
    }
    
    // Update call UI based on call type
    function updateCallUI() {
        if (callType === 'voice') {
            // Hide video elements
            localVideo.style.display = 'none';
            videoBtn.style.display = 'none';
            screenShareBtn.style.display = 'none';
            
            // Add voice call class
            callContainer.classList.add('voice-call');
        }
    }
    
    // Toggle mute
    muteBtn.addEventListener('click', function() {
        if (localStream) {
            const audioTracks = localStream.getAudioTracks();
            
            if (audioTracks.length > 0) {
                const audioTrack = audioTracks[0];
                audioTrack.enabled = !audioTrack.enabled;
                
                isMuted = !audioTrack.enabled;
                
                // Update button
                if (isMuted) {
                    muteBtn.innerHTML = '<i class="bi bi-mic-mute-fill"></i>';
                    muteBtn.classList.add('active');
                } else {
                    muteBtn.innerHTML = '<i class="bi bi-mic-fill"></i>';
                    muteBtn.classList.remove('active');
                }
            }
        }
    });
    
    // Toggle video
    if (videoBtn) {
        videoBtn.addEventListener('click', function() {
            if (localStream) {
                const videoTracks = localStream.getVideoTracks();
                
                if (videoTracks.length > 0) {
                    const videoTrack = videoTracks[0];
                    videoTrack.enabled = !videoTrack.enabled;
                    
                    isVideoOff = !videoTrack.enabled;
                    
                    // Update button
                    if (isVideoOff) {
                        videoBtn.innerHTML = '<i class="bi bi-camera-video-off-fill"></i>';
                        videoBtn.classList.add('active');
                    } else {
                        videoBtn.innerHTML = '<i class="bi bi-camera-video-fill"></i>';
                        videoBtn.classList.remove('active');
                    }
                    
                    // Update local video
                    localVideo.style.display = isVideoOff ? 'none' : 'block';
                }
            }
        });
    }
    
    // Toggle screen share
    if (screenShareBtn) {
        screenShareBtn.addEventListener('click', function() {
            if (isScreenSharing) {
                // Stop screen sharing
                stopScreenSharing();
            } else {
                // Start screen sharing
                startScreenSharing();
            }
        });
    }
    
    // Start screen sharing
    function startScreenSharing() {
        if (!isCallActive) return;
        
        navigator.mediaDevices.getDisplayMedia({ video: true })
            .then(stream => {
                screenShareStream = stream;
                
                // Replace video track
                const videoTrack = screenShareStream.getVideoTracks()[0];
                
                const senders = peerConnection.getSenders();
                const videoSender = senders.find(sender => 
                    sender.track && sender.track.kind === 'video'
                );
                
                if (videoSender) {
                    videoSender.replaceTrack(videoTrack);
                } else {
                    peerConnection.addTrack(videoTrack, screenShareStream);
                }
                
                // Update local video
                localVideo.srcObject = screenShareStream;
                localVideo.style.display = 'block';
                
                // Update button
                screenShareBtn.innerHTML = '<i class="bi bi-stop-fill"></i>';
                screenShareBtn.classList.add('active');
                
                // Set screen sharing flag
                isScreenSharing = true;
                
                // Handle end of screen sharing
                videoTrack.addEventListener('ended', () => {
                    stopScreenSharing();
                });
            })
            .catch(error => {
                console.error('Error starting screen sharing:', error);
                showToast('Error', 'Failed to start screen sharing.');
            });
    }
    
    // Stop screen sharing
    function stopScreenSharing() {
        if (!isScreenSharing || !screenShareStream) return;
        
        // Stop screen share tracks
        screenShareStream.getTracks().forEach(track => track.stop());
        
        // Replace with camera video track
        if (localStream && peerConnection) {
            const videoTrack = localStream.getVideoTracks()[0];
            
            if (videoTrack) {
                const senders = peerConnection.getSenders();
                const videoSender = senders.find(sender => 
                    sender.track && sender.track.kind === 'video'
                );
                
                if (videoSender) {
                    videoSender.replaceTrack(videoTrack);
                }
                
                // Update local video
                localVideo.srcObject = localStream;
                
                // Show/hide based on video state
                localVideo.style.display = isVideoOff ? 'none' : 'block';
            }
        }
        
        // Update button
        screenShareBtn.innerHTML = '<i class="bi bi-display"></i>';
        screenShareBtn.classList.remove('active');
        
        // Reset screen sharing flag
        isScreenSharing = false;
        screenShareStream = null;
    }
    
    // End call button
    endCallBtn.addEventListener('click', function() {
        // Send call ended message
        callSocket.send(JSON.stringify({
            'type': 'call_ended',
            'call_id': callId
        }));
        
        endCall('Call ended');
    });
    
    // Generate call ID
    function generateCallId() {
        return Date.now().toString() + Math.random().toString(36).substr(2, 5);
    }
}

// Initialize Dashboard
function initializeDashboard() {
    const dashboardContainer = document.getElementById('dashboard-container');
    const onlineUsersList = document.getElementById('online-users-list');
    
    // Connect to WebSocket for online users
    const discoverySocket = new WebSocket(
        'ws://' + window.location.host + '/ws/discovery/'
    );
    
    discoverySocket.onmessage = function(e) {
        const data = JSON.parse(e.data);
        
        if (data.type === 'online_users') {
            // Update online users
            updateOnlineUsers(data.users);
        }
    };
    
    // Update online users list
    function updateOnlineUsers(users) {
        onlineUsers = users;
        
        if (onlineUsersList) {
            // Clear list
            onlineUsersList.innerHTML = '';
            
            // Add users
            for (const userId in users) {
                if (userId === currentUser.id) continue;
                
                const user = users[userId];
                const userElement = document.createElement('div');
                userElement.className = 'user-card';
                
                userElement.innerHTML = `
                    <div class="user-card-avatar">
                        <div class="avatar">
                            ${user.avatar ? 
                                `<img src="${user.avatar}" alt="${user.username}">` : 
                                user.username.charAt(0).toUpperCase()
                            }
                            <span class="avatar-status avatar-status-${user.status}"></span>
                        </div>
                    </div>
                    <div class="user-card-info">
                        <div class="user-card-name">${user.username}</div>
                        <div class="user-card-status">${getStatusText(user.status)}</div>
                    </div>
                    <div class="user-card-actions">
                        <button class="btn btn-sm btn-primary rounded-circle chat-btn" data-user-id="${userId}" title="Chat">
                            <i class="bi bi-chat"></i>
                        </button>
                        <button class="btn btn-sm btn-success rounded-circle voice-call-btn" data-user-id="${userId}" title="Voice Call">
                            <i class="bi bi-telephone"></i>
                        </button>
                        <button class="btn btn-sm btn-info rounded-circle video-call-btn" data-user-id="${userId}" title="Video Call">
                            <i class="bi bi-camera-video"></i>
                        </button>
                    </div>
                `;
                
                // Add event listeners
                userElement.querySelector('.chat-btn').addEventListener('click', function() {
                    window.location.href = `/chat/${userId}/`;
                });
                
                userElement.querySelector('.voice-call-btn').addEventListener('click', function() {
                    window.location.href = `/call/${userId}/?type=voice`;
                });
                
                userElement.querySelector('.video-call-btn').addEventListener('click', function() {
                    window.location.href = `/call/${userId}/?type=video`;
                });
                
                onlineUsersList.appendChild(userElement);
            }
            
            // Show empty state if no users
            if (Object.keys(users).length <= 1) {
                onlineUsersList.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="bi bi-people"></i>
                        </div>
                        <h4 class="empty-state-title">No users online</h4>
                        <p class="empty-state-text">Invite others to join LAN_TALK to chat with them.</p>
                    </div>
                `;
            }
        }
    }
    
    // Get status text
    function getStatusText(status) {
        switch (status) {
            case 'online':
                return 'Online';
            case 'away':
                return 'Away';
            case 'busy':
                return 'Busy';
            case 'offline':
                return 'Offline';
            default:
                return 'Unknown';
        }
    }
}

// Show emoji picker
function showEmojiPicker(targetInput, triggerElement) {
    // Check if emoji picker already exists
    let emojiPicker = document.getElementById('emoji-picker');
    
    if (emojiPicker) {
        // Remove existing picker
        emojiPicker.remove();
        return;
    }
    
    // Create emoji picker
    emojiPicker = document.createElement('div');
    emojiPicker.id = 'emoji-picker';
    emojiPicker.className = 'emoji-picker';
    
    // Emoji categories
    const categories = [
        { name: 'Smileys & Emotion', icon: 'bi-emoji-smile', emojis: ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩', '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣', '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬', '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗', '🤔', '🤭', '🤫', '🤥', '😶', '😐', '😑', '😬', '🙄', '😯', '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐', '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕'] },
        { name: 'People & Body', icon: 'bi-person', emojis: ['👋', '🤚', '🖐️', '✋', '🖖', '👌', '🤌', '🤏', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆', '🖕', '👇', '☝️', '👍', '👎', '✊', '👊', '🤛', '🤜', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '✍️', '💅', '🤳', '💪', '🦾', '🦵', '🦿', '🦶', '👣', '👂', '🦻', '👃', '🧠', '🫀', '🫁', '🦷', '🦴', '👀', '👁️', '👅', '👄', '💋', '🩸'] },
        { name: 'Animals & Nature', icon: 'bi-flower1', emojis: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐻‍❄️', '🐨', '🐯', '🦁', '🐮', '🐷', '🐽', '🐸', '🐵', '🙈', '🙉', '🙊', '🐒', '🐔', '🐧', '🐦', '🐤', '🐣', '🐥', '🦆', '🦅', '🦉', '🦇', '🐺', '🐗', '🐴', '🦄', '🐝', '🪱', '🐛', '🦋', '🐌', '🐞', '🐜', '🪰', '🪲', '🪳', '🦟', '🦗', '🕷️', '🕸️', '🦂', '🐢', '🐍', '🦎', '🦖', '🦕', '🐙', '🦑', '🦐', '🦞', '🦀', '🐡', '🐠', '🐟', '🐬', '🐳', '🐋', '🦈', '🐊', '🐅', '🐆', '🦓', '🦍', '🦧', '🦣', '🐘', '🦛', '🦏', '🐪', '🐫', '🦒', '🦘', '🦬', '🐃', '🐂', '🐄', '🐎', '🐖', '🐏', '🐑', '🦙', '🐐', '🦌', '🐕', '🐩', '🦮', '🐕‍🦺', '🐈', '🐈‍⬛', '🪶', '🐓', '🦃', '🦤', '🦚', '🦜', '🦢', '🦩', '🕊️', '🐇', '🦝', '🦨', '🦡', '🦫', '🦦', '🦥', '🐁', '🐀', '🐿️', '🦔', '🐾', '🐉', '🐲', '🌵', '🎄', '🌲', '🌳', '🌴', '🪵', '🌱', '🌿', '☘️', '🍀', '🎍', '🪴', '🎋', '🍃', '🍂', '🍁', '🍄', '🐚', '🪨', '🌾', '💐', '🌷', '🌹', '🥀', '🌺', '🌸', '🌼', '🌻', '🌞', '🌝', '🌛', '🌜', '🌚', '🌕', '🌖', '🌗', '🌘', '🌑', '🌒', '🌓', '🌔', '🌙', '🌎', '🌍', '🌏', '🪐', '💫', '⭐', '🌟', '✨', '⚡', '☄️', '💥', '🔥', '🌪️', '🌈', '☀️', '🌤️', '⛅', '🌥️', '☁️', '🌦️', '🌧️', '⛈️', '🌩️', '🌨️', '❄️', '☃️', '⛄', '🌬️', '💨', '💧', '💦', '☔', '☂️', '🌊', '🌫️'] },
        { name: 'Food & Drink', icon: 'bi-cup-hot', emojis: ['🍏', '🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅', '🍆', '🥑', '🥦', '🥬', '🥒', '🌶️', '🫑', '🌽', '🥕', '🫒', '🧄', '🧅', '🥔', '🍠', '🥐', '🥯', '🍞', '🥖', '🥨', '🧀', '🥚', '🍳', '🧈', '🥞', '🧇', '🥓', '🥩', '🍗', '🍖', '🦴', '🌭', '🍔', '🍟', '🍕', '🫓', '🥪', '🥙', '🧆', '🌮', '🌯', '🫔', '🥗', '🥘', '🫕', '🥫', '🍝', '🍜', '🍲', '🍛', '🍣', '🍱', '🥟', '🦪', '🍤', '🍙', '🍚', '🍘', '🍥', '🥠', '🥮', '🍢', '🍡', '🍧', '🍨', '🍦', '🥧', '🧁', '🍰', '🎂', '🍮', '🍭', '🍬', '🍫', '🍿', '🍩', '🍪', '🌰', '🥜', '🫘', '🍯', '🥛', '🍼', '🫖', '☕', '🍵', '🧃', '🥤', '🧋', '🍶', '🍺', '🍻', '🥂', '🍷', '🥃', '🍸', '🍹', '🧉', '🍾', '🧊', '🥄', '🍴', '🍽️', '🥣', '🥡', '🥢', '🧂'] },
        { name: 'Travel & Places', icon: 'bi-geo-alt', emojis: ['🚗', '🚕', '🚙', '🚌', '🚎', '🏎️', '🚓', '🚑', '🚒', '🚐', '🛻', '🚚', '🚛', '🚜', '🦯', '🦽', '🦼', '🛴', '🚲', '🛵', '🏍️', '🛺', '🚨', '🚔', '🚍', '🚘', '🚖', '🚡', '🚠', '🚟', '🚃', '🚋', '🚞', '🚝', '🚄', '🚅', '🚈', '🚂', '🚆', '🚇', '🚊', '🚉', '✈️', '🛫', '🛬', '🛩️', '💺', '🛰️', '🚀', '🛸', '🚁', '🛶', '⛵', '🚤', '🛥️', '🛳️', '⛴️', '🚢', '⚓', '🪝', '⛽', '🚧', '🚦', '🚥', '🚏', '🗺️', '🗿', '🗽', '🗼', '🏰', '🏯', '🏟️', '🎡', '🎢', '🎠', '⛲', '⛱️', '🏖️', '🏝️', '🏜️', '🌋', '⛰️', '🏔️', '🗻', '🏕️', '⛺', '🛖', '🏠', '🏡', '🏘️', '🏚️', '🏗️', '🏢', '🏭', '🏬', '🏣', '🏤', '🏥', '🏦', '🏨', '🏪', '🏫', '🏩', '💒', '🏛️', '⛪', '🕌', '🕍', '🛕', '🕋', '⛩️', '🛤️', '🛣️', '🗾', '🎑', '🏞️', '🌅', '🌄', '🌠', '🎇', '🎆', '🌇', '🌆', '🏙️', '🌃', '🌌', '🌉', '🌁'] },
        { name: 'Activities', icon: 'bi-controller', emojis: ['⚽', '🏀', '🏈', '⚾', '🥎', '🎾', '🏐', '🏉', '🥏', '🎱', '🪀', '🏓', '🏸', '🏒', '🏑', '🥍', '🏏', '🪃', '🥅', '⛳', '🪁', '🏹', '🎣', '🤿', '🥊', '🥋', '🎽', '🛹', '🛼', '🛷', '⛸️', '🥌', '🎿', '⛷️', '🏂', '🪂', '🏋️', '🏋️‍♂️', '🏋️‍♀️', '🤼', '🤼‍♂️', '🤼‍♀️', '🤸', '🤸‍♂️', '🤸‍♀️', '⛹️', '⛹️‍♂️', '⛹️‍♀️', '🤺', '🤾', '🤾‍♂️', '🤾‍♀️', '🏌️', '🏌️‍♂️', '🏌️‍♀️', '🏇', '🧘', '🧘‍♂️', '🧘‍♀️', '🏄', '🏄‍♂️', '🏄‍♀️', '🏊', '🏊‍♂️', '🏊‍♀️', '🤽', '🤽‍♂️', '🤽‍♀️', '🚣', '🚣‍♂️', '🚣‍♀️', '🧗', '🧗‍♂️', '🧗‍♀️', '🚵', '🚵‍♂️', '🚵‍♀️', '🚴', '🚴‍♂️', '🚴‍♀️', '🏆', '🥇', '🥈', '🥉', '🏅', '🎖️', '🏵️', '🎗️', '🎫', '🎟️', '🎪', '🤹', '🤹‍♂️', '🤹‍♀️', '🎭', '🩰', '🎨', '🎬', '🎤', '🎧', '🎼', '🎹', '🥁', '🪘', '🎷', '🎺', '🪗', '🎸', '🪕', '🎻', '🎲', '♟️', '🎯', '🎳', '🎮', '🎰', '🧩'] },
        { name: 'Objects', icon: 'bi-lightbulb', emojis: ['⌚', '📱', '📲', '💻', '⌨️', '🖥️', '🖨️', '🖱️', '🖲️', '🕹️', '🗜️', '💽', '💾', '💿', '📀', '📼', '📷', '📸', '📹', '🎥', '📽️', '🎞️', '📞', '☎️', '📟', '📠', '📺', '📻', '🎙️', '🎚️', '🎛️', '🧭', '⏱️', '⏲️', '⏰', '🕰️', '⌛', '⏳', '📡', '🔋', '🔌', '💡', '🔦', '🕯️', '🪔', '🧯', '🛢️', '💸', '💵', '💴', '💶', '💷', '🪙', '💰', '💳', '💎', '⚖️', '🪜', '🧰', '🪛', '🔧', '🔨', '⚒️', '🛠️', '⛏️', '🪚', '🔩', '⚙️', '🪤', '🧱', '⛓️', '🧲', '🔫', '💣', '🧨', '🪓', '🔪', '🗡️', '⚔️', '🛡️', '🚬', '⚰️', '🪦', '⚱️', '🏺', '🔮', '📿', '🧿', '💈', '⚗️', '🔭', '🔬', '🕳️', '🩹', '🩺', '💊', '💉', '🩸', '🧬', '🦠', '🧫', '🧪', '🌡️', '🧹', '🪠', '🧺', '🧻', '🚽', '🚰', '🚿', '🛁', '🛀', '🧼', '🪥', '🪒', '🧽', '🪣', '🧴', '🛎️', '🔑', '🗝️', '🚪', '🪑', '🛋️', '🛏️', '🛌', '🧸', '🪆', '🖼️', '🪞', '🪟', '🛍️', '🛒', '🎁', '🎈', '🎏', '🎀', '🪄', '🪅', '🎊', '🎉', '🎎', '🏮', '🎐', '🧧', '✉️', '📩', '📨', '📧', '💌', '📥', '📤', '📦', '🏷️', '📪', '📫', '📬', '📭', '📮', '📯', '📜', '📃', '📄', '📑', '🧾', '📊', '📈', '📉', '🗒️', '🗓️', '📆', '📅', '🗑️', '📇', '🗃️', '🗳️', '🗄️', '📋', '📁', '📂', '🗂️', '🗞️', '📰', '📓', '📔', '📒', '📕', '📗', '📘', '📙', '📚', '📖', '🔖', '🧷', '🔗', '📎', '🖇️', '📐', '📏', '🧮', '📌', '📍', '✂️', '🖊️', '🖋️', '✒️', '🖌️', '🖍️', '📝', '✏️', '🔍', '🔎', '🔏', '🔐', '🔒', '🔓'] },
        { name: 'Symbols', icon: 'bi-hash', emojis: ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️', '✝️', '☪️', '🕉️', '☸️', '✡️', '🔯', '🕎', '☯️', '☦️', '🛐', '⛎', '♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓', '🆔', '⚛️', '🉑', '☢️', '☣️', '📴', '📳', '🈶', '🈚', '🈸', '🈺', '🈷️', '✴️', '🆚', '💮', '🉐', '㊙️', '㊗️', '🈴', '🈵', '🈹', '🈲', '🅰️', '🅱️', '🆎', '🆑', '🅾️', '🆘', '❌', '⭕', '🛑', '⛔', '📛', '🚫', '💯', '💢', '♨️', '🚷', '🚯', '🚳', '🚱', '🔞', '📵', '🚭', '❗', '❕', '❓', '❔', '‼️', '⁉️', '🔅', '🔆', '〽️', '⚠️', '🚸', '🔱', '⚜️', '🔰', '♻️', '✅', '🈯', '💹', '❇️', '✳️', '❎', '🌐', '💠', 'Ⓜ️', '🌀', '💤', '🏧', '🚾', '♿', '🅿️', '🛗', '🈳', '🈂️', '🛂', '🛃', '🛄', '🛅', '🚹', '🚺', '🚼', '⚧️', '🚻', '🚮', '🎦', '📶', '🈁', '🔣', 'ℹ️', '🔤', '🔡', '🔠', '🆖', '🆗', '🆙', '🆒', '🆕', '🆓', '0️⃣', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟', '🔢', '#️⃣', '*️⃣', '⏏️', '▶️', '⏸️', '⏯️', '⏹️', '⏺️', '⏭️', '⏮️', '⏩', '⏪', '⏫', '⏬', '◀️', '🔼', '🔽', '➡️', '⬅️', '⬆️', '⬇️', '↗️', '↘️', '↙️', '↖️', '↕️', '↔️', '↪️', '↩️', '⤴️', '⤵️', '🔀', '🔁', '🔂', '🔄', '🔃', '🎵', '🎶', '➕', '➖', '➗', '✖️', '♾️', '💲', '💱', '™️', '©️', '®️', '〰️', '➰', '➿', '🔚', '🔙', '🔛', '🔝', '🔜', '✔️', '☑️', '🔘', '🔴', '🟠', '🟡', '🟢', '🔵', '🟣', '⚫', '⚪', '🟤', '🔺', '🔻', '🔸', '🔹', '🔶', '🔷', '🔳', '🔲', '▪️', '▫️', '◾', '◽', '◼️', '◻️', '🟥', '🟧', '🟨', '🟩', '🟦', '🟪', '⬛', '⬜', '🟫', '🔈', '🔇', '🔉', '🔊', '🔔', '🔕', '📣', '📢', '👁️‍🗨️', '💬', '💭', '🗯️', '♠️', '♣️', '♥️', '♦️', '🃏', '🎴', '🀄', '🕐', '🕑', '🕒', '🕓', '🕔', '🕕', '🕖', '🕗', '🕘', '🕙', '🕚', '🕛', '🕜', '🕝', '🕞', '🕟', '🕠', '🕡', '🕢', '🕣', '🕤', '🕥', '🕦', '🕧'] },
        { name: 'Flags', icon: 'bi-flag', emojis: ['🏳️', '🏴', '🏁', '🚩', '🏳️‍🌈', '🏳️‍⚧️', '🏴‍☠️', '🇦🇫', '🇦🇽', '🇦🇱', '🇩🇿', '🇦🇸', '🇦🇩', '🇦🇴', '🇦🇮', '🇦🇶', '🇦🇬', '🇦🇷', '🇦🇲', '🇦🇼', '🇦🇺', '🇦🇹', '🇦🇿', '🇧🇸', '🇧🇭', '🇧🇩', '🇧🇧', '🇧🇾', '🇧🇪', '🇧🇿', '🇧🇯', '🇧🇲', '🇧🇹', '🇧🇴', '🇧🇦', '🇧🇼', '🇧🇷', '🇮🇴', '🇻🇬', '🇧🇳', '🇧🇬', '🇧🇫', '🇧🇮', '🇰🇭', '🇨🇲', '🇨🇦', '🇮🇨', '🇨🇻', '🇧🇶', '🇰🇾', '🇨🇫', '🇹🇩', '🇨🇱', '🇨🇳', '🇨🇽', '🇨🇨', '🇨🇴', '🇰🇲', '🇨🇬', '🇨🇩', '🇨🇰', '🇨🇷', '🇨🇮', '🇭🇷', '🇨🇺', '🇨🇼', '🇨🇾', '🇨🇿', '🇩🇰', '🇩🇯', '🇩🇲', '🇩🇴', '🇪🇨', '🇪🇬', '🇸🇻', '🇬🇶', '🇪🇷', '🇪🇪', '🇪🇹', '🇪🇺', '🇫🇰', '🇫🇴', '🇫🇯', '🇫🇮', '🇫🇷', '🇬🇫', '🇵🇫', '🇹🇫', '🇬🇦', '🇬🇲', '🇬🇪', '🇩🇪', '🇬🇭', '🇬🇮', '🇬🇷', '🇬🇱', '🇬🇩', '🇬🇵', '🇬🇺', '🇬🇹', '🇬🇬', '🇬🇳', '🇬🇼', '🇬🇾', '🇭🇹', '🇭🇳', '🇭🇰', '🇭🇺', '🇮🇸', '🇮🇳', '🇮🇩', '🇮🇷', '🇮🇶', '🇮🇪', '🇮🇲', '🇮🇱', '🇮🇹', '🇯🇲', '🇯🇵', '🎌', '🇯🇪', '🇯🇴', '🇰🇿', '🇰🇪', '🇰🇮', '🇽🇰', '🇰🇼', '🇰🇬', '🇱🇦', '🇱🇻', '🇱🇧', '🇱🇸', '🇱🇷', '🇱🇾', '🇱🇮', '🇱🇹', '🇱🇺', '🇲🇴', '🇲🇰', '🇲🇬', '🇲🇼', '🇲🇾', '🇲🇻', '🇲🇱', '🇲🇹', '🇲🇭', '🇲🇶', '🇲🇷', '🇲🇺', '🇾🇹', '🇲🇽', '🇫🇲', '🇲🇩', '🇲🇨', '🇲🇳', '🇲🇪', '🇲🇸', '🇲🇦', '🇲🇿', '🇲🇲', '🇳🇦', '🇳🇷', '🇳🇵', '🇳🇱', '🇳🇨', '🇳🇿', '🇳🇮', '🇳🇪', '🇳🇬', '🇳🇺', '🇳🇫', '🇰🇵', '🇲🇵', '🇳🇴', '🇴🇲', '🇵🇰', '🇵🇼', '🇵🇸', '🇵🇦', '🇵🇬', '🇵🇾', '🇵🇪', '🇵🇭', '🇵🇳', '🇵🇱', '🇵🇹', '🇵🇷', '🇶🇦', '🇷🇪', '🇷🇴', '🇷🇺', '🇷🇼', '🇼🇸', '🇸🇲', '🇸🇦', '🇸🇳', '🇷🇸', '🇸🇨', '🇸🇱', '🇸🇬', '🇸🇽', '🇸🇰', '🇸🇮', '🇬🇸', '🇸🇧', '🇸🇴', '🇿🇦', '🇰🇷', '🇸🇸', '🇪🇸', '🇱🇰', '🇧🇱', '🇸🇭', '🇰🇳', '🇱🇨', '🇵🇲', '🇻🇨', '🇸🇩', '🇸🇷', '🇸🇿', '🇸🇪', '🇨🇭', '🇸🇾', '🇹🇼', '🇹🇯', '🇹🇿', '🇹🇭', '🇹🇱', '🇹🇬', '🇹🇰', '🇹🇴', '🇹🇹', '🇹🇳', '🇹🇷', '🇹🇲', '🇹🇨', '🇹🇻', '🇻🇮', '🇺🇬', '🇺🇦', '🇦🇪', '🇬🇧', '🏴󠁧󠁢󠁥󠁮󠁧󠁿', '🏴󠁧󠁢󠁳󠁣󠁴󠁿', '🏴󠁧󠁢󠁷󠁬󠁳󠁿', '🇺🇳', '🇺🇸', '🇺🇾', '🇺🇿', '🇻🇺', '🇻🇦', '🇻🇪', '🇻🇳', '🇼🇫', '🇪🇭', '🇾🇪', '🇿🇲', '🇿🇼'] }
    ];
    
    // Create category tabs
    const categoryTabs = document.createElement('div');
    categoryTabs.className = 'emoji-picker-tabs';
    
    categories.forEach((category, index) => {
        const tab = document.createElement('div');
        tab.className = 'emoji-picker-tab';
        tab.dataset.category = index;
        tab.innerHTML = `<i class="bi ${category.icon}"></i>`;
        tab.title = category.name;
        
        if (index === 0) {
            tab.classList.add('active');
        }
        
        tab.addEventListener('click', function() {
            // Update active tab
            document.querySelectorAll('.emoji-picker-tab').forEach(tab => {
                tab.classList.remove('active');
            });
            this.classList.add('active');
            
            // Show corresponding category
            document.querySelectorAll('.emoji-picker-category').forEach(category => {
                category.style.display = 'none';
            });
            document.querySelector(`.emoji-picker-category[data-category="${this.dataset.category}"]`).style.display = 'grid';
        });
        
        categoryTabs.appendChild(tab);
    });
    
    emojiPicker.appendChild(categoryTabs);
    
    // Create emoji container
    const emojiContainer = document.createElement('div');
    emojiContainer.className = 'emoji-picker-container';
    
    // Create categories
    categories.forEach((category, index) => {
        const categoryElement = document.createElement('div');
        categoryElement.className = 'emoji-picker-category';
        categoryElement.dataset.category = index;
        categoryElement.style.display = index === 0 ? 'grid' : 'none';
        
        // Add emojis
        category.emojis.forEach(emoji => {
            const emojiElement = document.createElement('div');
            emojiElement.className = 'emoji-picker-emoji';
            emojiElement.textContent = emoji;
            
            emojiElement.addEventListener('click', function() {
                // Insert emoji at cursor position
                const cursorPosition = targetInput.selectionStart;
                const textBeforeCursor = targetInput.value.substring(0, cursorPosition);
                const textAfterCursor = targetInput.value.substring(cursorPosition);
                
                targetInput.value = textBeforeCursor + emoji + textAfterCursor;
                
                // Update cursor position
                targetInput.selectionStart = cursorPosition + emoji.length;
                targetInput.selectionEnd = cursorPosition + emoji.length;
                
                // Focus input
                targetInput.focus();
                
                // Remove emoji picker
                emojiPicker.remove();
            });
            
            categoryElement.appendChild(emojiElement);
        });
        
        emojiContainer.appendChild(categoryElement);
    });
    
    emojiPicker.appendChild(emojiContainer);
    
    // Add search
    const searchContainer = document.createElement('div');
    searchContainer.className = 'emoji-picker-search';
    
    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.placeholder = 'Search emojis...';
    searchInput.className = 'emoji-picker-search-input';
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        
        if (searchTerm) {
            // Hide categories
            document.querySelectorAll('.emoji-picker-category').forEach(category => {
                category.style.display = 'none';
            });
            
            // Show search results
            const searchResults = document.querySelector('.emoji-picker-search-results');
            searchResults.style.display = 'grid';
            searchResults.innerHTML = '';
            
            // Search emojis
            let found = false;
            
            categories.forEach(category => {
                category.emojis.forEach(emoji => {
                    if (category.name.toLowerCase().includes(searchTerm)) {
                        const emojiElement = document.createElement('div');
                        emojiElement.className = 'emoji-picker-emoji';
                        emojiElement.textContent = emoji;
                        
                        emojiElement.addEventListener('click', function() {
                            // Insert emoji at cursor position
                            const cursorPosition = targetInput.selectionStart;
                            const textBeforeCursor = targetInput.value.substring(0, cursorPosition);
                            const textAfterCursor = targetInput.value.substring(cursorPosition);
                            
                            targetInput.value = textBeforeCursor + emoji + textAfterCursor;
                            
                            // Update cursor position
                            targetInput.selectionStart = cursorPosition + emoji.length;
                            targetInput.selectionEnd = cursorPosition + emoji.length;
                            
                            // Focus input
                            targetInput.focus();
                            
                            // Remove emoji picker
                            emojiPicker.remove();
                        });
                        
                        searchResults.appendChild(emojiElement);
                        found = true;
                    }
                });
            });
            
            if (!found) {
                searchResults.innerHTML = '<div class="emoji-picker-no-results">No results found</div>';
            }
        } else {
            // Show first category
            document.querySelectorAll('.emoji-picker-category').forEach((category, index) => {
                category.style.display = index === 0 ? 'grid' : 'none';
            });
            
            // Hide search results
            document.querySelector('.emoji-picker-search-results').style.display = 'none';
            
            // Reset active tab
            document.querySelectorAll('.emoji-picker-tab').forEach((tab, index) => {
                tab.classList.toggle('active', index === 0);
            });
        }
    });
    
    searchContainer.appendChild(searchInput);
    emojiPicker.appendChild(searchContainer);
    
    // Add search results container
    const searchResults = document.createElement('div');
    searchResults.className = 'emoji-picker-search-results';
    searchResults.style.display = 'none';
    emojiPicker.appendChild(searchResults);
    
    // Position emoji picker
    const triggerRect = triggerElement.getBoundingClientRect();
    const viewportHeight = window.innerHeight;
    const viewportWidth = window.innerWidth;
    
    // Add to document
    document.body.appendChild(emojiPicker);
    
    // Get emoji picker dimensions
    const pickerRect = emojiPicker.getBoundingClientRect();
    
    // Position picker
    let top = triggerRect.bottom + 10;
    let left = triggerRect.left;
    
    // Check if picker would go off bottom of viewport
    if (top + pickerRect.height > viewportHeight) {
        top = triggerRect.top - pickerRect.height - 10;
    }
    
    // Check if picker would go off right of viewport
    if (left + pickerRect.width > viewportWidth) {
        left = viewportWidth - pickerRect.width - 10;
    }
    
    // Check if picker would go off left of viewport
    if (left < 10) {
        left = 10;
    }
    
    // Set position
    emojiPicker.style.top = `${top}px`;
    emojiPicker.style.left = `${left}px`;
    
    // Close picker when clicking outside
    document.addEventListener('click', function closeEmojiPicker(e) {
        if (!emojiPicker.contains(e.target) && e.target !== triggerElement) {
            emojiPicker.remove();
            document.removeEventListener('click', closeEmojiPicker);
        }
    });
    
    // Close picker when pressing Escape
    document.addEventListener('keydown', function escapeEmojiPicker(e) {
        if (e.key === 'Escape') {
            emojiPicker.remove();
            document.removeEventListener('keydown', escapeEmojiPicker);
        }
    });
    
    // Focus search input
    setTimeout(() => {
        searchInput.focus();
    }, 100);
}
