from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib.auth.models import User
from .models import ChatRoom, Message, MessageReaction, ReadReceipt
from django.db.models import Q
import json
import uuid
import os
from django.conf import settings
from django.utils import timezone

@login_required
def chat_home(request):
    # Get all chat rooms for the current user
    chat_rooms = request.user.chat_rooms.all().order_by('-messages__timestamp')
    
    context = {
        'chat_rooms': chat_rooms
    }
    return render(request, 'chat/chat_home.html', context)

@login_required
def chat_room(request, room_name):
    # Get or create chat room
    room, created = ChatRoom.objects.get_or_create(name=room_name)
    
    # If room was just created, add current user as participant
    if created:
        room.participants.add(request.user)
    
    # Get other participants
    other_participants = room.get_other_participants(request.user)
    
    # If this is a direct chat and no other participant, try to find the user
    if not other_participants.exists() and room_name.startswith('direct_'):
        try:
            # Extract username from room name (format: direct_user1_user2)
            usernames = room_name.split('_')[1:]
            other_username = usernames[0] if usernames[0] != request.user.username else usernames[1]
            other_user = User.objects.get(username=other_username)
            
            # Add other user as participant
            room.participants.add(other_user)
            other_participants = User.objects.filter(id=other_user.id)
        except (IndexError, User.DoesNotExist):
            pass
    
    # Get messages for this room
    messages = room.messages.all().order_by('timestamp')
    
    # Mark all messages as read for current user
    if messages.exists():
        last_message = messages.last()
        room.update_last_read(request.user, last_message.id)
    
    context = {
        'room': room,
        'room_name': room_name,
        'room_name_json': json.dumps(room_name),
        'username': json.dumps(request.user.username),
        'messages': messages,
        'other_participants': other_participants
    }
    return render(request, 'chat/chat_room.html', context)

@login_required
def start_chat(request, username):
    # Get the other user
    other_user = get_object_or_404(User, username=username)
    
    # Create a unique room name for direct chat (alphabetically sorted usernames)
    usernames = sorted([request.user.username, other_user.username])
    room_name = f"direct_{usernames[0]}_{usernames[1]}"
    
    # Get or create the chat room
    room, created = ChatRoom.objects.get_or_create(name=room_name)
    
    # Add both users as participants
    room.participants.add(request.user, other_user)
    
    # Redirect to chat room
    return redirect('chat_room', room_name=room_name)

@login_required
def upload_file(request):
    if request.method == 'POST' and request.FILES.get('file'):
        uploaded_file = request.FILES['file']
        room_name = request.POST.get('room')
        
        # Generate unique filename
        filename = f"{uuid.uuid4()}_{uploaded_file.name}"
        
        # Create uploads directory if it doesn't exist
        upload_dir = os.path.join(settings.MEDIA_ROOT, 'uploads')
        os.makedirs(upload_dir, exist_ok=True)
        
        # Save file
        file_path = os.path.join(upload_dir, filename)
        with open(file_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
        
        # Generate file URL
        file_url = f"{settings.MEDIA_URL}uploads/{filename}"
        
        # Get file size in MB
        file_size = uploaded_file.size / (1024 * 1024)
        
        return JsonResponse({
            'status': 'success',
            'file_url': file_url,
            'file_name': uploaded_file.name,
            'file_size': f"{file_size:.2f} MB"
        })
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@login_required
def get_unread_count(request):
    # Get all chat rooms for the current user
    chat_rooms = request.user.chat_rooms.all()
    
    total_unread = 0
    unread_by_room = {}
    
    for room in chat_rooms:
        # Get last read message ID for this user in this room
        read_receipt = ReadReceipt.objects.filter(room=room, user=request.user).first()
        last_read_id = read_receipt.last_read_id if read_receipt else 0
        
        # Count unread messages
        unread_count = room.messages.filter(
            ~Q(sender=request.user),  # Not sent by current user
            id__gt=last_read_id  # ID greater than last read
        ).count()
        
        total_unread += unread_count
        unread_by_room[room.name] = unread_count
    
    return JsonResponse({
        'total_unread': total_unread,
        'unread_by_room': unread_by_room
    })

@login_required
def search_messages(request):
    query = request.GET.get('q', '')
    room_name = request.GET.get('room', '')
    
    if not query or not room_name:
        return JsonResponse({'status': 'error', 'message': 'Missing query or room name'})
    
    # Get chat room
    try:
        room = ChatRoom.objects.get(name=room_name)
    except ChatRoom.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Room not found'})
    
    # Search messages
    messages = room.messages.filter(content__icontains=query).order_by('-timestamp')
    
    # Format results
    results = []
    for message in messages:
        results.append({
            'id': message.id,
            'content': message.content,
            'sender': message.sender.username,
            'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'is_current_user': message.sender == request.user
        })
    
    return JsonResponse({
        'status': 'success',
        'results': results,
        'count': len(results)
    })

@login_required
def update_reaction(request, message_id):
    if request.method == 'POST':
        reaction = request.POST.get('reaction')
        
        if not reaction:
            return JsonResponse({'status': 'error', 'message': 'Missing reaction'})
        
        # Get message
        try:
            message = Message.objects.get(id=message_id)
        except Message.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Message not found'})
        
        # Check if user already reacted to this message
        existing_reaction = MessageReaction.objects.filter(
            message=message,
            user=request.user
        ).first()
        
        if existing_reaction:
            # Update existing reaction
            existing_reaction.reaction = reaction
            existing_reaction.save()
        else:
            # Create new reaction
            MessageReaction.objects.create(
                message=message,
                user=request.user,
                reaction=reaction
            )
        
        # Get updated reactions summary
        reactions_summary = message.get_reactions_summary()
        
        return JsonResponse({
            'status': 'success',
            'reactions': reactions_summary
        })
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@login_required
def delete_message(request, message_id):
    if request.method == 'POST':
        # Get message
        try:
            message = Message.objects.get(id=message_id)
        except Message.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Message not found'})
        
        # Check if user is the sender
        if message.sender != request.user:
            return JsonResponse({'status': 'error', 'message': 'You can only delete your own messages'})
        
        # Delete message
        message.delete()
        
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@login_required
def get_chat_history(request, room_name, before_id=None):
    # Get chat room
    try:
        room = ChatRoom.objects.get(name=room_name)
    except ChatRoom.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Room not found'})
    
    # Get messages
    messages_query = room.messages.all()
    
    # If before_id is provided, get messages before that ID
    if before_id:
        try:
            before_id = int(before_id)
            messages_query = messages_query.filter(id__lt=before_id)
        except ValueError:
            pass
    
    # Get 20 messages, ordered by timestamp
    messages = messages_query.order_by('-timestamp')[:20]
    
    # Format messages
    message_list = []
    for message in reversed(messages):
        reactions_summary = message.get_reactions_summary()
        
        message_list.append({
            'id': message.id,
            'content': message.content,
            'sender': message.sender.username,
            'timestamp': message.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'is_current_user': message.sender == request.user,
            'reactions': reactions_summary
        })
    
    return JsonResponse({
        'status': 'success',
        'messages': message_list,
        'has_more': messages.count() == 20
    })
