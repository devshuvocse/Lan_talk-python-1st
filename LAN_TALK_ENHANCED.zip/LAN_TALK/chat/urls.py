from django.urls import path
from . import views

urlpatterns = [
    path('', views.chat_home, name='chat_home'),
    path('<str:room_name>/', views.chat_room, name='chat_room'),
    path('start/<str:username>/', views.start_chat, name='start_chat'),
    path('upload-file/', views.upload_file, name='upload_file'),
    path('unread-count/', views.get_unread_count, name='get_unread_count'),
    path('search/', views.search_messages, name='search_messages'),
    path('reaction/<int:message_id>/', views.update_reaction, name='update_reaction'),
    path('delete/<int:message_id>/', views.delete_message, name='delete_message'),
    path('history/<str:room_name>/', views.get_chat_history, name='get_chat_history'),
    path('history/<str:room_name>/<int:before_id>/', views.get_chat_history, name='get_chat_history_before'),
]
