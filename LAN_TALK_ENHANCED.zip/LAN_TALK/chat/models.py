from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_online = models.BooleanField(default=False)
    last_active = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=100, blank=True, null=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    
    def __str__(self):
        return f"{self.user.username}'s profile"

class ChatRoom(models.Model):
    name = models.CharField(max_length=255, unique=True)
    participants = models.ManyToManyField(User, related_name='chat_rooms')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name
    
    def get_other_participants(self, user):
        return self.participants.exclude(id=user.id)
    
    def update_last_read(self, user, message_id):
        """Update the last read message for a user in this room"""
        read_receipt, created = ReadReceipt.objects.get_or_create(
            room=self,
            user=user,
            defaults={'last_read_id': message_id}
        )
        
        if not created:
            read_receipt.last_read_id = message_id
            read_receipt.timestamp = timezone.now()
            read_receipt.save()
        
        return read_receipt

class Message(models.Model):
    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['timestamp']
    
    def __str__(self):
        return f"{self.sender.username}: {self.content[:50]}"
    
    def get_reactions_summary(self):
        """Get a summary of reactions for this message"""
        reactions = {}
        for reaction in self.reactions.all():
            if reaction.reaction in reactions:
                reactions[reaction.reaction] += 1
            else:
                reactions[reaction.reaction] = 1
        return reactions

class MessageReaction(models.Model):
    message = models.ForeignKey(Message, on_delete=models.CASCADE, related_name='reactions')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    reaction = models.CharField(max_length=10)  # Emoji or reaction code
    timestamp = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('message', 'user')
    
    def __str__(self):
        return f"{self.user.username} reacted with {self.reaction} to message {self.message.id}"

class ReadReceipt(models.Model):
    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='read_receipts')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    last_read_id = models.IntegerField(default=0)  # ID of the last read message
    timestamp = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ('room', 'user')
    
    def __str__(self):
        return f"{self.user.username} read up to message {self.last_read_id} in {self.room.name}"
