import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import ChatRoom, Message, MessageReaction
from django.contrib.auth.models import User
from django.utils import timezone
import asyncio

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = f'chat_{self.room_name}'
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        
        # Accept the connection
        await self.accept()
        
        # Send typing status update
        self.typing_task = None
        self.is_typing = False
    
    async def disconnect(self, close_code):
        # Cancel typing indicator task if it exists
        if self.typing_task:
            self.typing_task.cancel()
            
        # If user was typing, send stopped typing notification
        if self.is_typing:
            user = self.scope['user']
            if user.is_authenticated:
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'typing_status',
                        'username': user.username,
                        'user_id': user.id,
                        'is_typing': False
                    }
                )
        
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )
    
    # Receive message from WebSocket
    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message_type = text_data_json.get('type', 'message')
        
        if message_type == 'message':
            message = text_data_json['message']
            username = text_data_json['username']
            
            # Generate a temporary message ID for tracking
            message_id = text_data_json.get('temp_id', None)
            
            # Save message to database
            saved_message = await self.save_message(username, message)
            
            # Send message to room group
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'message': message,
                    'username': username,
                    'message_id': saved_message.id,
                    'temp_id': message_id,
                    'timestamp': saved_message.timestamp.isoformat(),
                }
            )
            
            # Reset typing status
            if self.is_typing:
                self.is_typing = False
                user = self.scope['user']
                if user.is_authenticated:
                    await self.channel_layer.group_send(
                        self.room_group_name,
                        {
                            'type': 'typing_status',
                            'username': user.username,
                            'user_id': user.id,
                            'is_typing': False
                        }
                    )
        
        elif message_type == 'typing':
            is_typing = text_data_json['is_typing']
            username = text_data_json['username']
            user_id = text_data_json.get('user_id')
            
            # Update typing status
            self.is_typing = is_typing
            
            # Cancel existing typing timeout task if it exists
            if self.typing_task:
                self.typing_task.cancel()
                self.typing_task = None
            
            # If user is typing, set a timeout to automatically clear typing status
            if is_typing:
                self.typing_task = asyncio.create_task(self.typing_timeout())
            
            # Send typing status to room group
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'typing_status',
                    'username': username,
                    'user_id': user_id,
                    'is_typing': is_typing
                }
            )
        
        elif message_type == 'reaction':
            message_id = text_data_json['message_id']
            reaction = text_data_json['reaction']
            username = text_data_json['username']
            
            # Save reaction to database
            await self.save_reaction(username, message_id, reaction)
            
            # Send reaction to room group
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'message_reaction',
                    'message_id': message_id,
                    'reaction': reaction,
                    'username': username
                }
            )
        
        elif message_type == 'read_receipt':
            username = text_data_json['username']
            last_read_id = text_data_json['last_read_id']
            
            # Update read receipt in database
            await self.update_read_receipt(username, last_read_id)
            
            # Send read receipt to room group
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'read_receipt',
                    'username': username,
                    'last_read_id': last_read_id
                }
            )
    
    # Typing timeout handler
    async def typing_timeout(self):
        try:
            # Wait for 3 seconds
            await asyncio.sleep(3)
            
            # If still connected, send stopped typing notification
            if self.is_typing:
                self.is_typing = False
                user = self.scope['user']
                if user.is_authenticated:
                    await self.channel_layer.group_send(
                        self.room_group_name,
                        {
                            'type': 'typing_status',
                            'username': user.username,
                            'user_id': user.id,
                            'is_typing': False
                        }
                    )
        except asyncio.CancelledError:
            # Task was cancelled, do nothing
            pass
    
    # Receive message from room group
    async def chat_message(self, event):
        message = event['message']
        username = event['username']
        message_id = event['message_id']
        temp_id = event.get('temp_id')
        timestamp = event['timestamp']
        
        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'message',
            'message': message,
            'username': username,
            'message_id': message_id,
            'temp_id': temp_id,
            'timestamp': timestamp
        }))
    
    # Receive typing status from room group
    async def typing_status(self, event):
        username = event['username']
        user_id = event.get('user_id')
        is_typing = event['is_typing']
        
        # Send typing status to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'typing',
            'username': username,
            'user_id': user_id,
            'is_typing': is_typing
        }))
    
    # Receive message reaction from room group
    async def message_reaction(self, event):
        message_id = event['message_id']
        reaction = event['reaction']
        username = event['username']
        
        # Send reaction to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'reaction',
            'message_id': message_id,
            'reaction': reaction,
            'username': username
        }))
    
    # Receive read receipt from room group
    async def read_receipt(self, event):
        username = event['username']
        last_read_id = event['last_read_id']
        
        # Send read receipt to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'read_receipt',
            'username': username,
            'last_read_id': last_read_id
        }))
    
    @database_sync_to_async
    def save_message(self, username, message):
        # Get the room and user
        room = ChatRoom.objects.get(name=self.room_name)
        user = User.objects.get(username=username)
        
        # Create and save the message
        message_obj = Message.objects.create(
            room=room,
            sender=user,
            content=message,
            timestamp=timezone.now()
        )
        
        return message_obj
    
    @database_sync_to_async
    def save_reaction(self, username, message_id, reaction):
        user = User.objects.get(username=username)
        message = Message.objects.get(id=message_id)
        
        # Check if reaction already exists
        existing_reaction = MessageReaction.objects.filter(
            message=message,
            user=user
        ).first()
        
        if existing_reaction:
            # Update existing reaction
            existing_reaction.reaction = reaction
            existing_reaction.save()
        else:
            # Create new reaction
            MessageReaction.objects.create(
                message=message,
                user=user,
                reaction=reaction
            )
    
    @database_sync_to_async
    def update_read_receipt(self, username, last_read_id):
        room = ChatRoom.objects.get(name=self.room_name)
        user = User.objects.get(username=username)
        
        # Update user's last read message for this room
        room.update_last_read(user, last_read_id)

class OnlineStatusConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.group_name = 'online_status'
        
        # Join online status group
        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )
        
        # Accept the connection
        await self.accept()
        
        # Update user's online status
        user = self.scope['user']
        if user.is_authenticated:
            await self.update_user_status(user.id, True)
            
            # Notify all clients about the user's online status
            await self.channel_layer.group_send(
                self.group_name,
                {
                    'type': 'user_status',
                    'user_id': user.id,
                    'status': True,
                    'last_active': timezone.now().isoformat()
                }
            )
    
    async def disconnect(self, close_code):
        # Update user's online status
        user = self.scope['user']
        if user.is_authenticated:
            await self.update_user_status(user.id, False)
            
            # Notify all clients about the user's offline status
            await self.channel_layer.group_send(
                self.group_name,
                {
                    'type': 'user_status',
                    'user_id': user.id,
                    'status': False,
                    'last_active': timezone.now().isoformat()
                }
            )
        
        # Leave online status group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )
    
    # Receive status update from WebSocket
    async def receive(self, text_data):
        # This consumer doesn't expect to receive messages directly
        pass
    
    # Send status update to WebSocket
    async def user_status(self, event):
        user_id = event['user_id']
        status = event['status']
        last_active = event.get('last_active')
        
        # Send status update to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'status',
            'user_id': user_id,
            'status': status,
            'last_active': last_active
        }))
    
    @database_sync_to_async
    def update_user_status(self, user_id, status):
        try:
            user = User.objects.get(id=user_id)
            user.profile.is_online = status
            user.profile.last_active = timezone.now()
            user.profile.save()
        except User.DoesNotExist:
            pass
